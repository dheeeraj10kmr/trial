/*
  # Create employees table with RLS policies

  1. New Tables
    - `employees`
      - `id` (text, primary key) - Employee ID
      - `name` (text) - Employee full name
      - `emp_code` (text, unique) - Employee code
      - `designation` (text) - Job designation
      - `emp_type` (text) - Employment type (Full Time, Part Time, Contract)
      - `location` (text) - Work location
      - `uan` (text) - Universal Account Number
      - `pan` (text) - PAN card number
      - `pf_number` (text) - Provident Fund number
      - `doj` (text) - Date of joining
      - `email` (text) - Email address
      - `ctc_structure` (jsonb) - CTC structure data
      - `salary_structure` (jsonb) - Salary structure data
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Record update timestamp

  2. Security
    - Enable RLS on `employees` table
    - Add policy for authenticated users to read all employee data
    - Add policy for authenticated users to insert employee data
    - Add policy for authenticated users to update employee data
    - Add policy for authenticated users to delete employee data
*/

-- Create employees table if it doesn't exist
CREATE TABLE IF NOT EXISTS employees (
  id text PRIMARY KEY,
  name text NOT NULL,
  emp_code text UNIQUE NOT NULL,
  designation text DEFAULT '',
  emp_type text DEFAULT 'Full Time',
  location text DEFAULT '',
  uan text DEFAULT '',
  pan text DEFAULT '',
  pf_number text DEFAULT '',
  doj text DEFAULT '',
  email text NOT NULL,
  ctc_structure jsonb DEFAULT '[]'::jsonb,
  salary_structure jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated users to read employees" ON employees;
DROP POLICY IF EXISTS "Allow authenticated users to insert employees" ON employees;
DROP POLICY IF EXISTS "Allow authenticated users to update employees" ON employees;
DROP POLICY IF EXISTS "Allow authenticated users to delete employees" ON employees;

-- Create policies for authenticated users
CREATE POLICY "Allow authenticated users to read employees"
  ON employees
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert employees"
  ON employees
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update employees"
  ON employees
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete employees"
  ON employees
  FOR DELETE
  TO authenticated
  USING (true);

-- Create index on emp_code for better performance
CREATE INDEX IF NOT EXISTS idx_employees_emp_code ON employees(emp_code);

-- Create index on email for better performance
CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);