/*
  # Fix empsalary table unique constraints

  1. Schema Changes
    - Remove all problematic unique constraints on employee_id and emp_code
    - Add proper composite unique constraint on (emp_code, month, year, component_id)
    - Ensure created_at column exists with proper naming

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity with proper constraints

  3. Performance
    - Add optimized indexes for common query patterns
*/

-- First, drop any existing problematic unique constraints
DO $$
DECLARE
    constraint_record RECORD;
BEGIN
    -- Drop any unique constraint that contains employee_id or just emp_code alone
    FOR constraint_record IN 
        SELECT constraint_name 
        FROM information_schema.table_constraints 
        WHERE table_name = 'empsalary' 
        AND constraint_type = 'UNIQUE'
        AND constraint_name IN ('empsalary_employee_id_key', 'empsalary_emp_code_key')
    LOOP
        EXECUTE 'ALTER TABLE empsalary DROP CONSTRAINT IF EXISTS ' || constraint_record.constraint_name;
    END LOOP;
END $$;

-- Ensure the created_at column exists (rename from created_date if needed)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'empsalary' AND column_name = 'created_date'
  ) THEN
    ALTER TABLE empsalary RENAME COLUMN created_date TO created_at;
  END IF;
  
  -- Add created_at column if it doesn't exist at all
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'empsalary' AND column_name = 'created_at'
  ) THEN
    ALTER TABLE empsalary ADD COLUMN created_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Add the correct composite unique constraint
DO $$
BEGIN
  -- First drop the constraint if it exists to avoid conflicts
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'empsalary_unique_component' 
    AND table_name = 'empsalary'
  ) THEN
    ALTER TABLE empsalary DROP CONSTRAINT empsalary_unique_component;
  END IF;
  
  -- Now add the correct constraint
  ALTER TABLE empsalary ADD CONSTRAINT empsalary_unique_component 
  UNIQUE (emp_code, month, year, component_id);
END $$;

-- Create optimized indexes for better performance
CREATE INDEX IF NOT EXISTS idx_empsalary_emp_code_month_year 
ON empsalary(emp_code, month, year);

CREATE INDEX IF NOT EXISTS idx_empsalary_component_lookup 
ON empsalary(emp_code, component_id, year, month);

-- Verify the table structure
DO $$
BEGIN
  -- Log the current constraints for verification
  RAISE NOTICE 'Current unique constraints on empsalary table:';
  
  -- This will show in the Supabase logs
  PERFORM constraint_name 
  FROM information_schema.table_constraints 
  WHERE table_name = 'empsalary' 
  AND constraint_type = 'UNIQUE';
END $$;