/*
  # Fix empsalary table schema constraints

  1. Schema Changes
    - Drop the overly restrictive unique constraint on employee_id
    - Add proper composite unique constraint on (emp_code, month, year, component_id)
    - Rename created_date column to created_at for consistency with application code

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity with proper constraints
*/

-- Drop the problematic unique constraint on employee_id
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'empsalary_employee_id_key' 
    AND table_name = 'empsalary'
  ) THEN
    ALTER TABLE empsalary DROP CONSTRAINT empsalary_employee_id_key;
  END IF;
END $$;

-- Rename created_date to created_at if the column exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'empsalary' AND column_name = 'created_date'
  ) THEN
    ALTER TABLE empsalary RENAME COLUMN created_date TO created_at;
  END IF;
END $$;

-- Add proper composite unique constraint to prevent duplicate salary components
-- for the same employee, month, year, and component
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'empsalary_unique_component' 
    AND table_name = 'empsalary'
  ) THEN
    ALTER TABLE empsalary ADD CONSTRAINT empsalary_unique_component 
    UNIQUE (emp_code, month, year, component_id);
  END IF;
END $$;

-- Create index for better performance on common queries
CREATE INDEX IF NOT EXISTS idx_empsalary_emp_code_month_year 
ON empsalary(emp_code, month, year);