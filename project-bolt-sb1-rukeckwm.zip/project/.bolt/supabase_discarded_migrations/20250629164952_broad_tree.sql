/*
  # Add created_date column to empsalary table

  1. Changes
    - Add `created_date` column to `empsalary` table with timestamptz type
    - Set default value to current timestamp
    - Update existing records to have a created_date value

  2. Security
    - No RLS changes needed as this is just adding a column
*/

-- Add the created_date column to empsalary table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'empsalary' AND column_name = 'created_date'
  ) THEN
    ALTER TABLE empsalary ADD COLUMN created_date timestamptz DEFAULT now();
    
    -- Update existing records to have a created_date value
    UPDATE empsalary SET created_date = now() WHERE created_date IS NULL;
  END IF;
END $$;