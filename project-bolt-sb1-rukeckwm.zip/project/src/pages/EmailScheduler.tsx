import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Schedule } from '../types';
import { Calendar, Clock, Mail, Plus, Edit2, Trash2, Play, Pause, Send } from 'lucide-react';
import { sendEmail } from '../utils/emailService';
import { calculateYearToDate } from '../utils/database';

export default function EmailScheduler() {
  const { state, dispatch } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
  const [showSendModal, setShowSendModal] = useState(false);

  const handleAddSchedule = () => {
    setEditingSchedule(null);
    setShowAddModal(true);
  };

  const handleEditSchedule = (schedule: Schedule) => {
    setEditingSchedule(schedule);
    setShowAddModal(true);
  };

  const handleDeleteSchedule = (scheduleId: string) => {
    if (window.confirm('Are you sure you want to delete this schedule?')) {
      dispatch({ type: 'DELETE_SCHEDULE', payload: scheduleId });
    }
  };

  const handleToggleSchedule = (schedule: Schedule) => {
    dispatch({
      type: 'UPDATE_SCHEDULE',
      payload: { ...schedule, active: !schedule.active }
    });
  };

  const getCurrentMonth = () => {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[new Date().getMonth()];
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Email Scheduler</h1>
          <p className="text-gray-600">Automate payslip email delivery with scheduled dispatch</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowSendModal(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
          >
            <Send className="h-4 w-4" />
            <span>Send Now</span>
          </button>
          <button
            onClick={handleAddSchedule}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Schedule</span>
          </button>
        </div>
      </div>

      {/* Email Configuration */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Default Email Configuration</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              From Email
            </label>
            <input
              type="email"
              defaultValue="payroll@diligentixconsulting.com"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Subject Template
            </label>
            <input
              type="text"
              defaultValue="Payslip for {month} {year} - {employeeName}"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Template
            </label>
            <textarea
              rows={8}
              defaultValue={`Dear {employeeName},

I hope this email finds you well.

Please find attached your salary slip for {month} {year}.

The payslip contains detailed information about your earnings, deductions, and net payable amount for the month.

Net Payable Amount: {netPayable}

If you have any questions or need clarification regarding your payslip, please don't hesitate to reach out to the HR department.

Thank you for your continued dedication and hard work.

Best regards,
Diligentix Consulting`}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Schedules List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Scheduled Email Dispatch</h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Employees
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Month/Year
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Day of Month
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Next Run
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {state.schedules.map((schedule) => {
                const employees = state.employees.filter(emp => schedule.employeeIds.includes(emp.id));
                return (
                  <tr key={schedule.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                        <div>
                          <span className="text-sm font-medium text-gray-900">
                            {employees.length} employee(s)
                          </span>
                          <div className="text-xs text-gray-500">
                            {employees.slice(0, 2).map(emp => emp.name).join(', ')}
                            {employees.length > 2 && ` +${employees.length - 2} more`}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {schedule.month} {schedule.year}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {schedule.dayOfMonth}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {schedule.time}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(schedule.nextRun).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => handleToggleSchedule(schedule)}
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          schedule.active
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {schedule.active ? (
                          <>
                            <Play className="h-3 w-3 mr-1" />
                            Active
                          </>
                        ) : (
                          <>
                            <Pause className="h-3 w-3 mr-1" />
                            Inactive
                          </>
                        )}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEditSchedule(schedule)}
                          className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteSchedule(schedule.id)}
                          className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {state.schedules.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No schedules configured</h3>
            <p className="text-gray-500 mb-4">
              Create your first email schedule to automate payslip delivery.
            </p>
            <button
              onClick={handleAddSchedule}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Add Schedule
            </button>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Send Now</h3>
            <Mail className="h-6 w-6 text-blue-600" />
          </div>
          <p className="text-gray-600 text-sm mb-4">
            Send payslips immediately to selected employees for the current month.
          </p>
          <button 
            onClick={() => setShowSendModal(true)}
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Send Payslips
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Test Email</h3>
            <Clock className="h-6 w-6 text-green-600" />
          </div>
          <p className="text-gray-600 text-sm mb-4">
            Send a test email to verify your email configuration is working.
          </p>
          <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors">
            Send Test Email
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Schedule Status</h3>
            <Calendar className="h-6 w-6 text-purple-600" />
          </div>
          <p className="text-gray-600 text-sm mb-4">
            View the status and history of all scheduled email dispatches.
          </p>
          <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors">
            View Logs
          </button>
        </div>
      </div>

      {/* Add/Edit Schedule Modal */}
      {showAddModal && (
        <ScheduleModal
          schedule={editingSchedule}
          employees={state.employees}
          onClose={() => setShowAddModal(false)}
          onSave={(schedule) => {
            if (editingSchedule) {
              dispatch({ type: 'UPDATE_SCHEDULE', payload: schedule });
            } else {
              dispatch({ type: 'ADD_SCHEDULE', payload: { ...schedule, id: Date.now().toString() } });
            }
            setShowAddModal(false);
          }}
        />
      )}

      {/* Send Now Modal */}
      {showSendModal && (
        <SendEmailModal
          employees={state.employees}
          onClose={() => setShowSendModal(false)}
          onSend={async (employeeIds, month, year) => {
            let successCount = 0;
            let failureCount = 0;

            for (const employeeId of employeeIds) {
              const employee = state.employees.find(emp => emp.id === employeeId);
              if (!employee) continue;

              try {
                // Calculate year-to-date values
                const salaryComponents = await calculateYearToDate(employee, month, year);

                const totalEarnings = salaryComponents
                  .filter(comp => comp.type === 'earning')
                  .reduce((sum, comp) => sum + comp.monthly, 0);
                
                const totalDeductions = salaryComponents
                  .filter(comp => comp.type === 'deduction')
                  .reduce((sum, comp) => sum + comp.monthly, 0);

                const netPayable = totalEarnings - totalDeductions;

                const emailResult = await sendEmail({
                  employee: { ...employee, paidDays: 22, leaveEncashmentDays: 0, noticePay: 0 },
                  month,
                  year,
                  salaryComponents,
                  totalEarnings,
                  totalDeductions,
                  netPayable,
                });

                // Add email log
                dispatch({
                  type: 'ADD_EMAIL_LOG',
                  payload: {
                    id: Date.now().toString() + employeeId,
                    payslipId: Date.now().toString(),
                    employeeId: employee.id,
                    employeeName: employee.name,
                    fromEmail: emailResult.fromEmail,
                    toEmail: emailResult.toEmail,
                    sentDate: new Date().toISOString(),
                    status: 'success',
                  },
                });

                successCount++;
              } catch (error) {
                // Add failed email log
                dispatch({
                  type: 'ADD_EMAIL_LOG',
                  payload: {
                    id: Date.now().toString() + employeeId,
                    payslipId: Date.now().toString(),
                    employeeId: employee.id,
                    employeeName: employee.name,
                    fromEmail: 'payroll@diligentixconsulting.com',
                    toEmail: employee.email,
                    sentDate: new Date().toISOString(),
                    status: 'failed',
                    errorMessage: error instanceof Error ? error.message : 'Unknown error',
                  },
                });

                failureCount++;
              }
            }

            alert(`Email sending completed!\nSuccessful: ${successCount}\nFailed: ${failureCount}`);
          }}
        />
      )}
    </div>
  );
}

function ScheduleModal({ 
  schedule, 
  employees,
  onClose, 
  onSave 
}: { 
  schedule: Schedule | null;
  employees: any[];
  onClose: () => void; 
  onSave: (schedule: Schedule) => void; 
}) {
  // Get current date info
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth(); // 0-based index

  // Month names array
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const getCurrentMonth = () => {
    return monthNames[currentMonth];
  };

  // Check if month/year is in future (beyond current month + 1)
  const isFutureMonthYear = (monthName: string, year: number): boolean => {
    const selectedMonthIndex = monthNames.indexOf(monthName);
    if (selectedMonthIndex === -1) return false;
    
    // Future years are not allowed
    if (year > currentYear) return true;
    
    // For current year, check if month is more than current month + 1
    if (year === currentYear && selectedMonthIndex > currentMonth + 1) return true;
    
    return false;
  };

  const [formData, setFormData] = useState<Partial<Schedule>>(
    schedule || {
      employeeIds: [],
      month: getCurrentMonth(),
      year: currentYear,
      dayOfMonth: 1,
      time: '09:00',
      active: true,
      nextRun: new Date().toISOString(),
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Schedule);
  };

  const handleEmployeeToggle = (employeeId: string) => {
    const currentIds = formData.employeeIds || [];
    if (currentIds.includes(employeeId)) {
      setFormData({
        ...formData,
        employeeIds: currentIds.filter(id => id !== employeeId)
      });
    } else {
      setFormData({
        ...formData,
        employeeIds: [...currentIds, employeeId]
      });
    }
  };

  const selectAllEmployees = () => {
    setFormData({
      ...formData,
      employeeIds: employees.map(emp => emp.id)
    });
  };

  const deselectAllEmployees = () => {
    setFormData({
      ...formData,
      employeeIds: []
    });
  };

  const handleMonthChange = (selectedMonth: string) => {
    setFormData({ ...formData, month: selectedMonth });
  };

  const handleYearChange = (selectedYear: number) => {
    setFormData({ ...formData, year: selectedYear });
  };

  const isFormValid = () => {
    const { month, year } = formData;
    if (!month || !year) return false;
    return !isFutureMonthYear(month, year);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">
            {schedule ? 'Edit Schedule' : 'Add New Schedule'}
          </h2>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Select Employees
              </label>
              <div className="space-x-2">
                <button
                  type="button"
                  onClick={selectAllEmployees}
                  className="text-xs text-blue-600 hover:text-blue-800"
                >
                  Select All
                </button>
                <button
                  type="button"
                  onClick={deselectAllEmployees}
                  className="text-xs text-gray-600 hover:text-gray-800"
                >
                  Deselect All
                </button>
              </div>
            </div>
            <div className="max-h-40 overflow-y-auto border border-gray-300 rounded-lg p-3 space-y-2">
              {employees.map(employee => (
                <label key={employee.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={(formData.employeeIds || []).includes(employee.id)}
                    onChange={() => handleEmployeeToggle(employee.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-900">
                    {employee.name} ({employee.empCode})
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Month
              </label>
              <select
                value={formData.month || getCurrentMonth()}
                onChange={(e) => handleMonthChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {monthNames.map((monthName, index) => {
                  const isDisabled = isFutureMonthYear(monthName, formData.year || currentYear);
                  
                  return (
                    <option 
                      key={monthName} 
                      value={monthName}
                      disabled={isDisabled}
                      style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                    >
                      {monthName}
                    </option>
                  );
                })}
              </select>
              {formData.month && isFutureMonthYear(formData.month, formData.year || currentYear) && (
                <p className="text-xs text-red-500 mt-1">Future months beyond next month are not allowed</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Year
              </label>
              <select
                value={formData.year || currentYear}
                onChange={(e) => handleYearChange(parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {/* Show years from 2020 to current year */}
                {Array.from({ length: currentYear - 2019 }, (_, i) => {
                  const yearOption = currentYear - i;
                  const isDisabled = yearOption > currentYear;
                  
                  return (
                    <option 
                      key={yearOption} 
                      value={yearOption}
                      disabled={isDisabled}
                      style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                    >
                      {yearOption}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Day of Month
            </label>
            <select
              value={formData.dayOfMonth || 1}
              onChange={(e) => setFormData({ ...formData, dayOfMonth: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {Array.from({ length: 28 }, (_, i) => i + 1).map(day => (
                <option key={day} value={day}>{day}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Time
            </label>
            <input
              type="time"
              value={formData.time || '09:00'}
              onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              id="active"
              checked={formData.active || false}
              onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="active" className="ml-2 block text-sm text-gray-900">
              Active
            </label>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={(formData.employeeIds || []).length === 0 || !isFormValid()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {schedule ? 'Update Schedule' : 'Add Schedule'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function SendEmailModal({
  employees,
  onClose,
  onSend,
}: {
  employees: any[];
  onClose: () => void;
  onSend: (employeeIds: string[], month: string, year: number) => void;
}) {
  // Get current date info
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth(); // 0-based index

  // Month names array
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const getCurrentMonth = () => {
    return monthNames[currentMonth];
  };

  // Check if month/year is in future (beyond current month + 1)
  const isFutureMonthYear = (monthName: string, year: number): boolean => {
    const selectedMonthIndex = monthNames.indexOf(monthName);
    if (selectedMonthIndex === -1) return false;
    
    // Future years are not allowed
    if (year > currentYear) return true;
    
    // For current year, check if month is more than current month + 1
    if (year === currentYear && selectedMonthIndex > currentMonth + 1) return true;
    
    return false;
  };

  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [month, setMonth] = useState(getCurrentMonth());
  const [year, setYear] = useState(currentYear);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedEmployees.length > 0 && !isFutureMonthYear(month, year)) {
      onSend(selectedEmployees, month, year);
      onClose();
    }
  };

  const handleEmployeeToggle = (employeeId: string) => {
    if (selectedEmployees.includes(employeeId)) {
      setSelectedEmployees(selectedEmployees.filter(id => id !== employeeId));
    } else {
      setSelectedEmployees([...selectedEmployees, employeeId]);
    }
  };

  const selectAllEmployees = () => {
    setSelectedEmployees(employees.map(emp => emp.id));
  };

  const deselectAllEmployees = () => {
    setSelectedEmployees([]);
  };

  const selectedEmps = employees.filter(emp => selectedEmployees.includes(emp.id));

  const isFormValid = () => {
    return selectedEmployees.length > 0 && !isFutureMonthYear(month, year);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Send Payslip Emails</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Select Employees
              </label>
              <div className="space-x-2">
                <button
                  type="button"
                  onClick={selectAllEmployees}
                  className="text-xs text-blue-600 hover:text-blue-800"
                >
                  Select All
                </button>
                <button
                  type="button"
                  onClick={deselectAllEmployees}
                  className="text-xs text-gray-600 hover:text-gray-800"
                >
                  Deselect All
                </button>
              </div>
            </div>
            <div className="max-h-40 overflow-y-auto border border-gray-300 rounded-lg p-3 space-y-2">
              {employees.map(employee => (
                <label key={employee.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedEmployees.includes(employee.id)}
                    onChange={() => handleEmployeeToggle(employee.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-900">
                    {employee.name} ({employee.empCode}) - {employee.email}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Month
              </label>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {monthNames.map((monthName, index) => {
                  const isDisabled = isFutureMonthYear(monthName, year);
                  
                  return (
                    <option 
                      key={monthName} 
                      value={monthName}
                      disabled={isDisabled}
                      style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                    >
                      {monthName}
                    </option>
                  );
                })}
              </select>
              {isFutureMonthYear(month, year) && (
                <p className="text-xs text-red-500 mt-1">Future months beyond next month are not allowed</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Year
              </label>
              <select
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {/* Show years from 2020 to current year */}
                {Array.from({ length: currentYear - 2019 }, (_, i) => {
                  const yearOption = currentYear - i;
                  const isDisabled = yearOption > currentYear;
                  
                  return (
                    <option 
                      key={yearOption} 
                      value={yearOption}
                      disabled={isDisabled}
                      style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                    >
                      {yearOption}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>

          {selectedEmps.length > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Email Preview</h4>
              <div className="text-sm text-gray-600 space-y-1">
                {selectedEmps.length === 1 ? (
                  // Show actual data for single employee
                  <>
                    <p><strong>To:</strong> {selectedEmps[0].email}</p>
                    <p><strong>Subject:</strong> Payslip for {month} {year} - {selectedEmps[0].name}</p>
                    <div className="mt-2">
                      <p><strong>Message:</strong></p>
                      <div className="bg-white p-3 rounded border text-xs">
                        Dear {selectedEmps[0].name},<br/><br/>
                        I hope this email finds you well.<br/><br/>
                        Please find attached your salary slip for {month} {year}.<br/><br/>
                        The payslip contains detailed information about your earnings, deductions, and net payable amount for the month.<br/><br/>
                        Net Payable Amount: [Amount will be calculated]<br/><br/>
                        If you have any questions or need clarification regarding your payslip, please don't hesitate to reach out to the HR department.<br/><br/>
                        Thank you for your continued dedication and hard work.<br/><br/>
                        Best regards,<br/>
                        Diligentix Consulting
                      </div>
                    </div>
                  </>
                ) : (
                  // Show template for multiple employees
                  <>
                    <p><strong>To:</strong> {selectedEmps.length} employee(s)</p>
                    <p><strong>Subject:</strong> Payslip for {month} {year} - [Employee Name]</p>
                    <div className="mt-2">
                      <p><strong>Message Template:</strong></p>
                      <div className="bg-white p-3 rounded border text-xs">
                        Dear [Employee Name],<br/><br/>
                        I hope this email finds you well.<br/><br/>
                        Please find attached your salary slip for {month} {year}.<br/><br/>
                        The payslip contains detailed information about your earnings, deductions, and net payable amount for the month.<br/><br/>
                        Net Payable Amount: [Amount will be calculated]<br/><br/>
                        If you have any questions or need clarification regarding your payslip, please don't hesitate to reach out to the HR department.<br/><br/>
                        Thank you for your continued dedication and hard work.<br/><br/>
                        Best regards,<br/>
                        Diligentix Consulting
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
          
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isFormValid()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              Send Emails ({selectedEmployees.length})
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}