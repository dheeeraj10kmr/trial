import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Payslip, Employee, SalaryComponent } from '../types';
import { Search, Download, Eye, Mail, Calendar, Filter, FileText } from 'lucide-react';
import PayslipTemplate from '../components/PayslipTemplate';
import { generatePDF } from '../utils/pdfGenerator';
import { sendEmail } from '../utils/emailService';
import { calculateYearToDate } from '../utils/database';

export default function PayslipsGenerated() {
  const { state, dispatch, loadPayslips } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('all');
  const [yearFilter, setYearFilter] = useState('all');
  const [selectedPayslips, setSelectedPayslips] = useState<string[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [previewPayslip, setPreviewPayslip] = useState<Payslip | null>(null);
  const [previewEmployee, setPreviewEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadPayslips();
  }, []);

  const filteredPayslips = state.payslips.filter(payslip => {
    const employee = state.employees.find(emp => emp.empCode === payslip.employeeId);
    const employeeName = employee?.name || '';
    
    const matchesSearch = employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payslip.employeeId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMonth = monthFilter === 'all' || payslip.month === monthFilter;
    const matchesYear = yearFilter === 'all' || payslip.year.toString() === yearFilter;
    
    return matchesSearch && matchesMonth && matchesYear;
  });

  const handleSelectPayslip = (payslipId: string) => {
    if (selectedPayslips.includes(payslipId)) {
      setSelectedPayslips(selectedPayslips.filter(id => id !== payslipId));
    } else {
      setSelectedPayslips([...selectedPayslips, payslipId]);
    }
  };

  const handleSelectAll = () => {
    if (selectedPayslips.length === filteredPayslips.length) {
      setSelectedPayslips([]);
    } else {
      setSelectedPayslips(filteredPayslips.map(p => p.id));
    }
  };

  const handlePreview = async (payslip: Payslip) => {
    const employee = state.employees.find(emp => emp.empCode === payslip.employeeId);
    if (!employee) {
      alert('Employee not found');
      return;
    }

    setLoading(true);
    try {
      // Recalculate YTD values for accurate display
      const updatedComponents = await calculateYearToDate(employee, payslip.month, payslip.year);
      
      const updatedPayslip = {
        ...payslip,
        salaryComponents: updatedComponents
      };

      setPreviewPayslip(updatedPayslip);
      setPreviewEmployee(employee);
      setShowPreview(true);
    } catch (error) {
      console.error('Error preparing preview:', error);
      // Fallback to original data
      setPreviewPayslip(payslip);
      setPreviewEmployee(employee);
      setShowPreview(true);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (payslip: Payslip) => {
    const employee = state.employees.find(emp => emp.empCode === payslip.employeeId);
    if (!employee) {
      alert('Employee not found');
      return;
    }

    setLoading(true);
    try {
      const updatedComponents = await calculateYearToDate(employee, payslip.month, payslip.year);
      
      const totalEarnings = updatedComponents
        .filter(comp => comp.type === 'earning')
        .reduce((sum, comp) => sum + comp.monthly, 0);
      
      const totalDeductions = updatedComponents
        .filter(comp => comp.type === 'deduction')
        .reduce((sum, comp) => sum + comp.monthly, 0);

      await generatePDF({
        employee: { ...employee, paidDays: 22, leaveEncashmentDays: 0, noticePay: 0 },
        month: payslip.month,
        year: payslip.year,
        salaryComponents: updatedComponents,
        totalEarnings,
        totalDeductions,
        netPayable: totalEarnings - totalDeductions,
      });
    } catch (error) {
      console.error('Error downloading payslip:', error);
      alert('Error downloading payslip. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendEmail = async (payslip: Payslip) => {
    const employee = state.employees.find(emp => emp.empCode === payslip.employeeId);
    if (!employee) {
      alert('Employee not found');
      return;
    }

    setLoading(true);
    try {
      const updatedComponents = await calculateYearToDate(employee, payslip.month, payslip.year);
      
      const totalEarnings = updatedComponents
        .filter(comp => comp.type === 'earning')
        .reduce((sum, comp) => sum + comp.monthly, 0);
      
      const totalDeductions = updatedComponents
        .filter(comp => comp.type === 'deduction')
        .reduce((sum, comp) => sum + comp.monthly, 0);

      const emailResult = await sendEmail({
        employee: { ...employee, paidDays: 22, leaveEncashmentDays: 0, noticePay: 0 },
        month: payslip.month,
        year: payslip.year,
        salaryComponents: updatedComponents,
        totalEarnings,
        totalDeductions,
        netPayable: totalEarnings - totalDeductions,
      });

      // Add email log
      dispatch({
        type: 'ADD_EMAIL_LOG',
        payload: {
          id: Date.now().toString(),
          payslipId: payslip.id,
          employeeId: employee.id,
          employeeName: employee.name,
          fromEmail: emailResult.fromEmail,
          toEmail: emailResult.toEmail,
          sentDate: new Date().toISOString(),
          status: 'success',
        },
      });

      alert('Email sent successfully!');
    } catch (error) {
      // Add failed email log
      dispatch({
        type: 'ADD_EMAIL_LOG',
        payload: {
          id: Date.now().toString(),
          payslipId: payslip.id,
          employeeId: employee.id,
          employeeName: employee.name,
          fromEmail: 'payroll@diligentixconsulting.com',
          toEmail: employee.email,
          sentDate: new Date().toISOString(),
          status: 'failed',
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
        },
      });

      alert('Failed to send email. Please check your email configuration.');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkDownload = async () => {
    if (selectedPayslips.length === 0) return;

    setLoading(true);
    let successCount = 0;
    let errorCount = 0;

    for (const payslipId of selectedPayslips) {
      try {
        const payslip = state.payslips.find(p => p.id === payslipId);
        if (payslip) {
          await handleDownload(payslip);
          successCount++;
        }
      } catch (error) {
        errorCount++;
      }
    }

    setLoading(false);
    alert(`Bulk download completed!\nSuccessful: ${successCount}\nFailed: ${errorCount}`);
  };

  const handleBulkEmail = async () => {
    if (selectedPayslips.length === 0) return;

    setLoading(true);
    let successCount = 0;
    let errorCount = 0;

    for (const payslipId of selectedPayslips) {
      try {
        const payslip = state.payslips.find(p => p.id === payslipId);
        if (payslip) {
          await handleSendEmail(payslip);
          successCount++;
        }
      } catch (error) {
        errorCount++;
      }
    }

    setLoading(false);
    alert(`Bulk email completed!\nSuccessful: ${successCount}\nFailed: ${errorCount}`);
  };

  const uniqueMonths = [...new Set(state.payslips.map(p => p.month))];
  const uniqueYears = [...new Set(state.payslips.map(p => p.year))];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payslips Generated</h1>
          <p className="text-gray-600">View and manage previously generated payslips</p>
        </div>
        <div className="flex items-center space-x-3">
          {selectedPayslips.length > 0 && (
            <>
              <button
                onClick={handleBulkDownload}
                disabled={loading}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
              >
                <Download className="h-4 w-4" />
                <span>Download Selected ({selectedPayslips.length})</span>
              </button>
              <button
                onClick={handleBulkEmail}
                disabled={loading}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
              >
                <Mail className="h-4 w-4" />
                <span>Email Selected ({selectedPayslips.length})</span>
              </button>
            </>
          )}
          <button
            onClick={loadPayslips}
            disabled={loading}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
          >
            <FileText className="h-4 w-4" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by employee name or code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex space-x-3">
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Months</option>
              {uniqueMonths.map(month => (
                <option key={month} value={month}>{month}</option>
              ))}
            </select>
            
            <select
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Years</option>
              {uniqueYears.map(year => (
                <option key={year} value={year.toString()}>{year}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Payslips Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectedPayslips.length === filteredPayslips.length && filteredPayslips.length > 0}
                    onChange={handleSelectAll}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Month/Year
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Net Payable
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Generated Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPayslips.map((payslip) => {
                const employee = state.employees.find(emp => emp.empCode === payslip.employeeId);
                return (
                  <tr key={payslip.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedPayslips.includes(payslip.id)}
                        onChange={() => handleSelectPayslip(payslip.id)}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {employee?.name || 'Unknown Employee'}
                        </div>
                        <div className="text-sm text-gray-500">
                          {payslip.employeeId} • {employee?.designation}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900">
                          {payslip.month} {payslip.year}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                      ₹{payslip.netPayable.toLocaleString('en-IN')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(payslip.generatedDate).toLocaleDateString('en-IN')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handlePreview(payslip)}
                          disabled={loading}
                          className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50 disabled:text-gray-400"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDownload(payslip)}
                          disabled={loading}
                          className="text-green-600 hover:text-green-900 p-1 rounded hover:bg-green-50 disabled:text-gray-400"
                        >
                          <Download className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleSendEmail(payslip)}
                          disabled={loading}
                          className="text-purple-600 hover:text-purple-900 p-1 rounded hover:bg-purple-50 disabled:text-gray-400"
                        >
                          <Mail className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredPayslips.length === 0 && (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No payslips found</h3>
            <p className="text-gray-500">
              {searchTerm || monthFilter !== 'all' || yearFilter !== 'all'
                ? 'No payslips match your current filters.'
                : 'No payslips have been generated yet. Start by generating payslips for your employees.'}
            </p>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      {showPreview && previewPayslip && previewEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                Payslip Preview - {previewEmployee.name} ({previewPayslip.month} {previewPayslip.year})
              </h2>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              <PayslipTemplate
                employee={{ ...previewEmployee, paidDays: 22, leaveEncashmentDays: 0, noticePay: 0 }}
                month={previewPayslip.month}
                year={previewPayslip.year}
                salaryComponents={previewPayslip.salaryComponents}
                totalEarnings={previewPayslip.totalEarnings}
                totalDeductions={previewPayslip.totalDeductions}
                netPayable={previewPayslip.netPayable}
              />
            </div>
          </div>
        </div>
      )}

      {loading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 flex items-center space-x-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <span className="text-gray-700">Processing...</span>
          </div>
        </div>
      )}
    </div>
  );
}