import React, { useState, useEffect } from 'react';
import { Building2, Mail, Shield, Database, Bell, Palette, CheckCircle, XCircle } from 'lucide-react';
import { saveSMTPConfig, saveEmailTemplate, saveSubjectTemplate, testSMTPConnection, sendTestEmail } from '../utils/emailService';

interface SMTPConfig {
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
  fromEmail: string;
  fromName: string;
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState('company');

  const tabs = [
    { id: 'company', name: 'Company', icon: Building2 },
    { id: 'email', name: 'Email', icon: Mail },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'appearance', name: 'Appearance', icon: Palette },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600">Manage your application preferences and configuration</p>
      </div>

      <div className="flex space-x-8">
        {/* Sidebar */}
        <div className="w-64 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <nav className="space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600'
                    : 'text-gray-700 hover:bg-gray-50 hover:text-blue-600'
                }`}
              >
                <tab.icon className="h-4 w-4 mr-3" />
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1">
          {activeTab === 'company' && <CompanySettings />}
          {activeTab === 'email' && <EmailSettings />}
          {activeTab === 'security' && <SecuritySettings />}
          {activeTab === 'notifications' && <NotificationSettings />}
          {activeTab === 'appearance' && <AppearanceSettings />}
        </div>
      </div>
    </div>
  );
}

function CompanySettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Company Information</h2>
      
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Company Name
            </label>
            <input
              type="text"
              defaultValue="Diligentix Consulting"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              CIN Number
            </label>
            <input
              type="text"
              defaultValue="U62099MH2024OPC436737"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Registered Address
          </label>
          <textarea
            rows={3}
            defaultValue="Office No. 6571/6572/17, Viman Nagar, Nashik-422207, Maharashtra, India."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number
            </label>
            <input
              type="tel"
              placeholder="+91 XXXXXXXXXX"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Website
            </label>
            <input
              type="url"
              placeholder="https://diligentixconsulting.com"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="pt-4">
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function EmailSettings() {
  const [smtpConfig, setSMTPConfig] = useState<SMTPConfig>({
    host: '',
    port: 587,
    secure: false,
    username: '',
    password: '',
    fromEmail: '',
    fromName: 'Diligentix Consulting',
  });

  const [emailTemplate, setEmailTemplate] = useState('');
  const [subjectTemplate, setSubjectTemplate] = useState('');
  const [testEmail, setTestEmail] = useState('');
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testEmailStatus, setTestEmailStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  useEffect(() => {
    // Load saved configuration
    const savedConfig = localStorage.getItem('smtp_config');
    if (savedConfig) {
      try {
        setSMTPConfig(JSON.parse(savedConfig));
      } catch (error) {
        console.error('Error loading SMTP config:', error);
      }
    }

    const savedEmailTemplate = localStorage.getItem('email_template');
    if (savedEmailTemplate) {
      setEmailTemplate(savedEmailTemplate);
    } else {
      setEmailTemplate(`Dear {employeeName},

I hope this email finds you well.

Please find attached your salary slip for {month} {year}.

The payslip contains detailed information about your earnings, deductions, and net payable amount for the month.

Net Payable Amount: {netPayable}

If you have any questions or need clarification regarding your payslip, please don't hesitate to reach out to the HR department.

Thank you for your continued dedication and hard work.

Best regards,
HR Department
Diligentix Consulting`);
    }

    const savedSubjectTemplate = localStorage.getItem('subject_template');
    if (savedSubjectTemplate) {
      setSubjectTemplate(savedSubjectTemplate);
    } else {
      setSubjectTemplate('Payslip for {month} {year} - {employeeName}');
    }
  }, []);

  const handleSaveSMTPConfig = () => {
    saveSMTPConfig(smtpConfig);
    alert('SMTP configuration saved successfully!');
  };

  const handleTestConnection = async () => {
    setConnectionStatus('testing');
    try {
      const success = await testSMTPConnection(smtpConfig);
      setConnectionStatus(success ? 'success' : 'error');
      setTimeout(() => setConnectionStatus('idle'), 3000);
    } catch (error) {
      setConnectionStatus('error');
      setTimeout(() => setConnectionStatus('idle'), 3000);
    }
  };

  const handleSendTestEmail = async () => {
    if (!testEmail) {
      alert('Please enter a test email address');
      return;
    }

    setTestEmailStatus('sending');
    try {
      await sendTestEmail(testEmail);
      setTestEmailStatus('success');
      setTimeout(() => setTestEmailStatus('idle'), 3000);
    } catch (error) {
      setTestEmailStatus('error');
      setTimeout(() => setTestEmailStatus('idle'), 3000);
    }
  };

  const handleSaveTemplates = () => {
    saveEmailTemplate(emailTemplate);
    saveSubjectTemplate(subjectTemplate);
    alert('Email templates saved successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">SMTP Configuration</h2>
        
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-800 mb-2">Environment Variables (Recommended)</h3>
            <p className="text-sm text-blue-700 mb-3">
              For production use, set these environment variables in your .env file:
            </p>
            <div className="bg-blue-100 rounded p-3 font-mono text-xs text-blue-800">
              <div>VITE_SMTP_HOST=your-smtp-server.com</div>
              <div>VITE_SMTP_PORT=587</div>
              <div>VITE_SMTP_SECURE=false</div>
              <div>VITE_SMTP_USERNAME=your-email@yourdomain.com</div>
              <div>VITE_SMTP_PASSWORD=your-app-password</div>
              <div>VITE_SMTP_FROM_EMAIL=noreply@yourdomain.com</div>
              <div>VITE_SMTP_FROM_NAME=Your Company Name</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                SMTP Server *
              </label>
              <input
                type="text"
                value={smtpConfig.host}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, host: e.target.value })}
                placeholder="smtp.gmail.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Port *
              </label>
              <input
                type="number"
                value={smtpConfig.port}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, port: parseInt(e.target.value) || 587 })}
                placeholder="587"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Username *
              </label>
              <input
                type="email"
                value={smtpConfig.username}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, username: e.target.value })}
                placeholder="your-email@yourdomain.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password *
              </label>
              <input
                type="password"
                value={smtpConfig.password}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, password: e.target.value })}
                placeholder="••••••••"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                From Email *
              </label>
              <input
                type="email"
                value={smtpConfig.fromEmail}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, fromEmail: e.target.value })}
                placeholder="noreply@yourdomain.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                From Name
              </label>
              <input
                type="text"
                value={smtpConfig.fromName}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, fromName: e.target.value })}
                placeholder="Your Company Name"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <label className="flex items-center">
              <input 
                type="checkbox" 
                checked={smtpConfig.secure}
                onChange={(e) => setSMTPConfig({ ...smtpConfig, secure: e.target.checked })}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" 
              />
              <span className="ml-2 text-sm text-gray-700">Use SSL/TLS (port 465)</span>
            </label>
          </div>

          <div className="flex items-center space-x-4">
            <button 
              onClick={handleSaveSMTPConfig}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Save SMTP Configuration
            </button>
            
            <button 
              onClick={handleTestConnection}
              disabled={connectionStatus === 'testing'}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 flex items-center space-x-2"
            >
              {connectionStatus === 'testing' && <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>}
              {connectionStatus === 'success' && <CheckCircle className="h-4 w-4" />}
              {connectionStatus === 'error' && <XCircle className="h-4 w-4" />}
              <span>
                {connectionStatus === 'testing' ? 'Testing...' : 
                 connectionStatus === 'success' ? 'Connected!' :
                 connectionStatus === 'error' ? 'Failed' : 'Test Connection'}
              </span>
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Test Email</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Test Email Address
            </label>
            <input
              type="email"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              placeholder="test@example.com"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <button 
            onClick={handleSendTestEmail}
            disabled={testEmailStatus === 'sending' || !testEmail}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-400 flex items-center space-x-2"
          >
            {testEmailStatus === 'sending' && <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>}
            {testEmailStatus === 'success' && <CheckCircle className="h-4 w-4" />}
            {testEmailStatus === 'error' && <XCircle className="h-4 w-4" />}
            <span>
              {testEmailStatus === 'sending' ? 'Sending...' : 
               testEmailStatus === 'success' ? 'Sent!' :
               testEmailStatus === 'error' ? 'Failed' : 'Send Test Email'}
            </span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Email Templates</h2>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Default Subject Line
            </label>
            <input
              type="text"
              value={subjectTemplate}
              onChange={(e) => setSubjectTemplate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Body Template
            </label>
            <textarea
              rows={12}
              value={emailTemplate}
              onChange={(e) => setEmailTemplate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="text-sm text-gray-600">
            <p className="font-medium mb-2">Available Variables:</p>
            <div className="grid grid-cols-2 gap-2">
              <span>• {'{employeeName}'} - Employee name</span>
              <span>• {'{empCode}'} - Employee code</span>
              <span>• {'{month}'} - Payslip month</span>
              <span>• {'{year}'} - Payslip year</span>
              <span>• {'{designation}'} - Employee designation</span>
              <span>• {'{netPayable}'} - Net payable amount</span>
            </div>
          </div>

          <button 
            onClick={handleSaveTemplates}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Save Email Templates
          </button>
        </div>
      </div>
    </div>
  );
}

function SecuritySettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Security Settings</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Password Policy</h3>
          <div className="space-y-3">
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Require at least 8 characters</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Require uppercase letters</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Require numbers</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Require special characters</span>
            </label>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Session Management</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Session Timeout (minutes)
              </label>
              <input
                type="number"
                defaultValue="30"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Max Failed Login Attempts
              </label>
              <input
                type="number"
                defaultValue="5"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Data Protection</h3>
          <div className="space-y-3">
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Encrypt payslip PDFs</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Enable audit logging</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Require 2FA for admin users</span>
            </label>
          </div>
        </div>

        <div className="pt-4">
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Save Security Settings
          </button>
        </div>
      </div>
    </div>
  );
}

function NotificationSettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Notification Preferences</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Email Notifications</h3>
          <div className="space-y-3">
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Payslip generation completed</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Email delivery failures</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Scheduled email dispatch</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">System maintenance alerts</span>
              <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Dashboard Alerts</h3>
          <div className="space-y-3">
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Show failed email notifications</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Show upcoming scheduled tasks</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Show system status warnings</span>
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Notification Email Address
          </label>
          <input
            type="email"
            defaultValue="admin@diligentixconsulting.com"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="pt-4">
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Save Notification Settings
          </button>
        </div>
      </div>
    </div>
  );
}

function AppearanceSettings() {
  const [currentTheme, setCurrentTheme] = useState(() => {
    return localStorage.getItem('theme') || 'light';
  });

  const applyTheme = (theme: string) => {
    const root = document.documentElement;
    
    if (theme === 'dark') {
      root.classList.add('dark');
      document.body.style.backgroundColor = '#1f2937';
      document.body.style.color = '#f9fafb';
    } else if (theme === 'auto') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
        document.body.style.backgroundColor = '#1f2937';
        document.body.style.color = '#f9fafb';
      } else {
        root.classList.remove('dark');
        document.body.style.backgroundColor = '#ffffff';
        document.body.style.color = '#111827';
      }
    } else {
      root.classList.remove('dark');
      document.body.style.backgroundColor = '#ffffff';
      document.body.style.color = '#111827';
    }
  };

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme);
    localStorage.setItem('theme', theme);
    applyTheme(theme);
  };

  // Apply theme on component mount
  React.useEffect(() => {
    applyTheme(currentTheme);
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Appearance Settings</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Theme</h3>
          <div className="grid grid-cols-3 gap-4">
            <label className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              currentTheme === 'light' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
            }`}>
              <div className="w-16 h-12 bg-white border rounded mb-2 shadow-sm"></div>
              <input 
                type="radio" 
                name="theme" 
                value="light" 
                checked={currentTheme === 'light'}
                onChange={(e) => handleThemeChange(e.target.value)}
                className="sr-only" 
              />
              <span className="text-sm font-medium">Light</span>
            </label>
            
            <label className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              currentTheme === 'dark' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
            }`}>
              <div className="w-16 h-12 bg-gray-800 rounded mb-2"></div>
              <input 
                type="radio" 
                name="theme" 
                value="dark" 
                checked={currentTheme === 'dark'}
                onChange={(e) => handleThemeChange(e.target.value)}
                className="sr-only" 
              />
              <span className="text-sm font-medium">Dark</span>
            </label>
            
            <label className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              currentTheme === 'auto' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
            }`}>
              <div className="w-16 h-12 bg-gradient-to-r from-white to-gray-800 rounded mb-2"></div>
              <input 
                type="radio" 
                name="theme" 
                value="auto" 
                checked={currentTheme === 'auto'}
                onChange={(e) => handleThemeChange(e.target.value)}
                className="sr-only" 
              />
              <span className="text-sm font-medium">Auto</span>
            </label>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Payslip Template</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Primary Color
              </label>
              <input
                type="color"
                defaultValue="#2563eb"
                className="w-20 h-10 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Font Family
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="arial">Arial</option>
                <option value="helvetica">Helvetica</option>
                <option value="times">Times New Roman</option>
                <option value="roboto">Roboto</option>
              </select>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Layout</h3>
          <div className="space-y-3">
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Compact sidebar</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Show breadcrumbs</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
              <span className="ml-2 text-sm text-gray-700">Enable animations</span>
            </label>
          </div>
        </div>

        <div className="pt-4">
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Save Appearance Settings
          </button>
        </div>
      </div>
    </div>
  );
}