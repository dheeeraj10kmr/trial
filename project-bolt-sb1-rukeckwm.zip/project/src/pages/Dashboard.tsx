import React from 'react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  FileText, 
  Mail, 
  TrendingUp,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';

export default function Dashboard() {
  const { state } = useApp();
  const navigate = useNavigate();

  const successfulEmails = state.emailLogs.filter(log => log.status === 'success').length;
  const failedEmails = state.emailLogs.filter(log => log.status === 'failed').length;
  const totalEmails = state.emailLogs.length;
  const successRate = totalEmails > 0 ? ((successfulEmails / totalEmails) * 100).toFixed(1) : '0';

  const stats = [
    {
      name: 'Total Employees',
      value: state.employees.length,
      change: '+12%',
      changeType: 'positive' as const,
      icon: Users,
    },
    {
      name: 'Payslips Generated',
      value: state.payslips.length,
      change: '+8%',
      changeType: 'positive' as const,
      icon: FileText,
    },
    {
      name: 'Emails Sent',
      value: successfulEmails,
      change: '+15%',
      changeType: 'positive' as const,
      icon: Mail,
    },
    {
      name: 'Success Rate',
      value: `${successRate}%`,
      change: '+2.1%',
      changeType: 'positive' as const,
      icon: TrendingUp,
    },
  ];

  const recentActivity = [
    ...state.payslips.slice(-3).map(payslip => {
      const employee = state.employees.find(emp => emp.id === payslip.employeeId);
      return {
        id: `payslip-${payslip.id}`,
        type: 'payslip_generated',
        message: `Payslip generated for ${employee?.name || 'Unknown Employee'}`,
        time: new Date(payslip.generatedDate).toLocaleString(),
        icon: FileText,
        color: 'text-blue-600',
      };
    }),
    ...state.emailLogs.slice(-3).map(log => ({
      id: `email-${log.id}`,
      type: 'email_sent',
      message: `Email ${log.status} for ${log.employeeName}`,
      time: new Date(log.sentDate).toLocaleString(),
      icon: Mail,
      color: log.status === 'success' ? 'text-green-600' : 'text-red-600',
    })),
  ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 5);

  const upcomingSchedules = state.schedules
    .filter(schedule => schedule.active)
    .slice(0, 3)
    .map(schedule => {
      const employees = state.employees.filter(emp => schedule.employeeIds.includes(emp.id));
      return {
        id: schedule.id,
        employees: employees,
        month: schedule.month,
        year: schedule.year,
        nextRun: new Date(schedule.nextRun),
        status: 'pending',
      };
    });

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's what's happening with your payroll.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => navigate('/generate')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Generate Payslips
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{stat.name}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <stat.icon className="h-6 w-6 text-gray-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <span className={`text-sm font-medium ${
                stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.change}
              </span>
              <span className="text-sm text-gray-500 ml-2">from last month</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivity.length > 0 ? (
              recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg bg-gray-50 ${activity.color}`}>
                    <activity.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p>No recent activity</p>
                <p className="text-sm">Start by adding employees and generating payslips</p>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button 
              onClick={() => navigate('/generate')}
              className="w-full flex items-center justify-between p-3 text-left bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <FileText className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">Generate Bulk Payslips</span>
              </div>
              <span className="text-blue-600">→</span>
            </button>
            <button 
              onClick={() => navigate('/employees')}
              className="w-full flex items-center justify-between p-3 text-left bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium text-green-900">Add New Employee</span>
              </div>
              <span className="text-green-600">→</span>
            </button>
            <button 
              onClick={() => navigate('/scheduler')}
              className="w-full flex items-center justify-between p-3 text-left bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium text-purple-900">Schedule Email</span>
              </div>
              <span className="text-purple-600">→</span>
            </button>
          </div>
        </div>

        {/* Upcoming Schedules */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Schedules</h3>
          <div className="space-y-4">
            {upcomingSchedules.length > 0 ? (
              upcomingSchedules.map((schedule) => (
                <div key={schedule.id} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-yellow-600" />
                    <div>
                      <p className="text-sm font-medium text-yellow-900">
                        {schedule.employees.length} employee(s) - {schedule.month} {schedule.year}
                      </p>
                      <p className="text-xs text-yellow-700">
                        {schedule.nextRun.toLocaleDateString()} at {schedule.nextRun.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs bg-yellow-200 text-yellow-800 px-2 py-1 rounded-full">Pending</span>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p>No upcoming schedules</p>
                <p className="text-sm">Set up email schedules to automate payslip delivery</p>
              </div>
            )}
          </div>
        </div>

        {/* System Status */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Email Service</span>
              <span className="flex items-center text-sm text-green-600">
                <CheckCircle className="h-4 w-4 mr-1" />
                Online
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">PDF Generation</span>
              <span className="flex items-center text-sm text-green-600">
                <CheckCircle className="h-4 w-4 mr-1" />
                Online
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Supabase Database</span>
              <span className="flex items-center text-sm text-green-600">
                <CheckCircle className="h-4 w-4 mr-1" />
                Connected
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Email Delivery Rate</span>
              <span className="flex items-center text-sm text-blue-600">
                <TrendingUp className="h-4 w-4 mr-1" />
                {successRate}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}