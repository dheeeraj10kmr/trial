import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Employee, SalaryComponent, Payslip, PayslipData } from '../types';
import { Download, Eye, Calculator, Mail } from 'lucide-react';
import PayslipTemplate from '../components/PayslipTemplate';
import { generatePDF } from '../utils/pdfGenerator';
import { sendEmail } from '../utils/emailService';
import { calculateYearToDate, savePayslipToDatabase } from '../utils/database';

export default function PayslipGenerator() {
  const { state, dispatch } = useApp();
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [month, setMonth] = useState('');
  const [year, setYear] = useState(new Date().getFullYear());
  const [salaryComponents, setSalaryComponents] = useState<SalaryComponent[]>([]);
  const [payslipData, setPayslipData] = useState<PayslipData>({
    paidDays: 30,
    leaveEncashmentDays: 0,
    noticePay: 0,
  });
  const [showPreview, setShowPreview] = useState(false);
  const [loading, setLoading] = useState(false);

  // Get current date info
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth(); // 0-based index

  // Month names array
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Get days in month
  const getDaysInMonth = (monthName: string, year: number): number => {
    const monthIndex = monthNames.indexOf(monthName);
    if (monthIndex === -1) return 30;
    return new Date(year, monthIndex + 1, 0).getDate();
  };

  // Check if month/year is valid for employee
  const isValidMonthYear = (employee: Employee, monthName: string, year: number): boolean => {
    if (!employee.doj) return true;
    
    const doj = new Date(employee.doj);
    const dojYear = doj.getFullYear();
    const dojMonth = doj.getMonth(); // 0-based
    
    const selectedMonthIndex = monthNames.indexOf(monthName);
    if (selectedMonthIndex === -1) return false;
    
    // Check if selected month/year is before DOJ
    if (year < dojYear) return false;
    if (year === dojYear && selectedMonthIndex < dojMonth) return false;
    
    return true;
  };

  // Check if month/year is in future (beyond current month + 1)
  const isFutureMonthYear = (monthName: string, year: number): boolean => {
    const selectedMonthIndex = monthNames.indexOf(monthName);
    if (selectedMonthIndex === -1) return false;
    
    // Future years are not allowed
    if (year > currentYear) return true;
    
    // For current year, check if month is more than current month + 1
    if (year === currentYear && selectedMonthIndex > currentMonth + 1) return true;
    
    return false;
  };

  const handleEmployeeSelect = async (employee: Employee) => {
    setSelectedEmployee(employee);
    setLoading(true);
    
    try {
      if (month) {
        // Calculate year-to-date values automatically
        const ytdComponents = await calculateYearToDate(employee, month, year);
        setSalaryComponents(ytdComponents);
        
        // Update paid days based on selected month
        const daysInMonth = getDaysInMonth(month, year);
        setPayslipData(prev => ({ ...prev, paidDays: daysInMonth }));
      } else {
        // Load salary structure from employee data without YTD calculation
        const components = employee.salaryStructure?.map(comp => ({
          id: comp.id,
          name: comp.name,
          monthly: comp.currentMonth,
          ytd: 0, // Will be calculated when month is selected
          type: comp.type,
        })) || [];
        setSalaryComponents(components);
      }
    } catch (error) {
      console.error('Error loading employee data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMonthChange = async (selectedMonth: string) => {
    setMonth(selectedMonth);
    
    // Update paid days based on selected month
    const daysInMonth = getDaysInMonth(selectedMonth, year);
    setPayslipData(prev => ({ ...prev, paidDays: daysInMonth }));
    
    if (selectedEmployee) {
      setLoading(true);
      try {
        // Recalculate YTD when month changes
        const ytdComponents = await calculateYearToDate(selectedEmployee, selectedMonth, year);
        setSalaryComponents(ytdComponents);
      } catch (error) {
        console.error('Error calculating YTD:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleYearChange = (selectedYear: number) => {
    setYear(selectedYear);
    
    // Update paid days if month is selected
    if (month) {
      const daysInMonth = getDaysInMonth(month, selectedYear);
      setPayslipData(prev => ({ ...prev, paidDays: daysInMonth }));
    }
    
    if (selectedEmployee && month) {
      setLoading(true);
      calculateYearToDate(selectedEmployee, month, selectedYear)
        .then(ytdComponents => {
          setSalaryComponents(ytdComponents);
        })
        .catch(error => {
          console.error('Error calculating YTD:', error);
        })
        .finally(() => {
          setLoading(false);
        });
    }
  };

  const handleComponentChange = (id: string, field: 'monthly' | 'ytd', value: number) => {
    setSalaryComponents(prev =>
      prev.map(comp =>
        comp.id === id ? { ...comp, [field]: value } : comp
      )
    );
  };

  const calculateTotals = () => {
    const earnings = salaryComponents.filter(comp => comp.type === 'earning');
    const deductions = salaryComponents.filter(comp => comp.type === 'deduction');
    
    const totalEarnings = earnings.reduce((sum, comp) => sum + comp.monthly, 0);
    const totalDeductions = deductions.reduce((sum, comp) => sum + comp.monthly, 0);
    const netPayable = totalEarnings - totalDeductions;

    return { totalEarnings, totalDeductions, netPayable };
  };

  const handleGeneratePayslip = async () => {
    if (!selectedEmployee || !month) return;

    setLoading(true);
    try {
      const { totalEarnings, totalDeductions, netPayable } = calculateTotals();

      // Save to database
      await savePayslipToDatabase(selectedEmployee, month, year, salaryComponents);

      const payslip: Payslip = {
        id: Date.now().toString(),
        employeeId: selectedEmployee.id,
        month,
        year,
        salaryComponents,
        payslipData,
        totalEarnings,
        totalDeductions,
        netPayable,
        generatedDate: new Date().toISOString(),
        status: 'generated',
      };

      dispatch({ type: 'ADD_PAYSLIP', payload: payslip });
      setShowPreview(true);
    } catch (error) {
      console.error('Error generating payslip:', error);
      alert('Error generating payslip. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!selectedEmployee) return;
    
    const { totalEarnings, totalDeductions, netPayable } = calculateTotals();
    
    await generatePDF({
      employee: { ...selectedEmployee, ...payslipData },
      month,
      year,
      salaryComponents,
      totalEarnings,
      totalDeductions,
      netPayable,
    });
  };

  const handleSendEmail = async () => {
    if (!selectedEmployee || !month) return;

    const { totalEarnings, totalDeductions, netPayable } = calculateTotals();

    setLoading(true);
    try {
      const emailResult = await sendEmail({
        employee: { ...selectedEmployee, ...payslipData },
        month,
        year,
        salaryComponents,
        totalEarnings,
        totalDeductions,
        netPayable,
      });

      // Add email log with from and to email details
      dispatch({
        type: 'ADD_EMAIL_LOG',
        payload: {
          id: Date.now().toString(),
          payslipId: Date.now().toString(),
          employeeId: selectedEmployee.id,
          employeeName: selectedEmployee.name,
          fromEmail: emailResult.fromEmail,
          toEmail: emailResult.toEmail,
          sentDate: new Date().toISOString(),
          status: 'success',
        },
      });

      alert('Email sent successfully!');
    } catch (error) {
      // Add failed email log
      dispatch({
        type: 'ADD_EMAIL_LOG',
        payload: {
          id: Date.now().toString(),
          payslipId: Date.now().toString(),
          employeeId: selectedEmployee.id,
          employeeName: selectedEmployee.name,
          fromEmail: 'payroll@diligentixconsulting.com',
          toEmail: selectedEmployee.email,
          sentDate: new Date().toISOString(),
          status: 'failed',
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
        },
      });

      alert('Failed to send email. Please check your email configuration.');
    } finally {
      setLoading(false);
    }
  };

  const { totalEarnings, totalDeductions, netPayable } = calculateTotals();

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Generate Payslip</h1>
          <p className="text-gray-600">Create and customize employee payslips</p>
        </div>
        <div className="flex items-center space-x-3">
          {selectedEmployee && (
            <>
              <button
                onClick={() => setShowPreview(true)}
                disabled={loading}
                className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
              >
                <Eye className="h-4 w-4" />
                <span>Preview</span>
              </button>
              <button
                onClick={handleDownloadPDF}
                disabled={loading}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
              >
                <Download className="h-4 w-4" />
                <span>Download PDF</span>
              </button>
              <button
                onClick={handleSendEmail}
                disabled={loading}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400"
              >
                <Mail className="h-4 w-4" />
                <span>Send Email</span>
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Employee Selection */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Employee</h3>
          <div className="space-y-3">
            {state.employees.map((employee) => (
              <div
                key={employee.id}
                onClick={() => handleEmployeeSelect(employee)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedEmployee?.id === employee.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className="font-medium text-gray-900">{employee.name}</div>
                <div className="text-sm text-gray-500">{employee.empCode} • {employee.designation}</div>
                {employee.doj && (
                  <div className="text-xs text-gray-400">DOJ: {new Date(employee.doj).toLocaleDateString('en-IN')}</div>
                )}
              </div>
            ))}
            {state.employees.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No employees found. Please add employees first.
              </div>
            )}
          </div>
        </div>

        {/* Payslip Configuration */}
        <div className="lg:col-span-2 space-y-6">
          {selectedEmployee && (
            <>
              {/* Month/Year Selection and Payslip Data */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Payslip Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Month
                    </label>
                    <select
                      value={month}
                      onChange={(e) => handleMonthChange(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Select Month</option>
                      {monthNames.map((monthName, index) => {
                        const isDisabled = selectedEmployee && (
                          !isValidMonthYear(selectedEmployee, monthName, year) ||
                          isFutureMonthYear(monthName, year)
                        );
                        
                        return (
                          <option 
                            key={monthName} 
                            value={monthName}
                            disabled={isDisabled}
                            style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                          >
                            {monthName}
                          </option>
                        );
                      })}
                    </select>
                    {selectedEmployee && month && !isValidMonthYear(selectedEmployee, month, year) && (
                      <p className="text-xs text-red-500 mt-1">Month is before employee's joining date</p>
                    )}
                    {selectedEmployee && month && isFutureMonthYear(month, year) && (
                      <p className="text-xs text-red-500 mt-1">Future months beyond next month are not allowed</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Year
                    </label>
                    <select
                      value={year}
                      onChange={(e) => handleYearChange(parseInt(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {/* Show years from 2020 to current year */}
                      {Array.from({ length: currentYear - 2019 }, (_, i) => {
                        const yearOption = currentYear - i;
                        const isDisabled = yearOption > currentYear;
                        
                        return (
                          <option 
                            key={yearOption} 
                            value={yearOption}
                            disabled={isDisabled}
                            style={isDisabled ? { color: '#9CA3AF', backgroundColor: '#F3F4F6' } : {}}
                          >
                            {yearOption}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Paid Days
                    </label>
                    <input
                      type="number"
                      value={payslipData.paidDays}
                      onChange={(e) => setPayslipData({ ...payslipData, paidDays: parseInt(e.target.value) || 0 })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min="0"
                      max={month ? getDaysInMonth(month, year) : 31}
                    />
                    {month && (
                      <p className="text-xs text-gray-500 mt-1">
                        Max: {getDaysInMonth(month, year)} days for {month}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Leave Encashment Days
                    </label>
                    <input
                      type="number"
                      value={payslipData.leaveEncashmentDays}
                      onChange={(e) => setPayslipData({ ...payslipData, leaveEncashmentDays: parseInt(e.target.value) || 0 })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Notice Pay
                    </label>
                    <input
                      type="number"
                      value={payslipData.noticePay}
                      onChange={(e) => setPayslipData({ ...payslipData, noticePay: parseInt(e.target.value) || 0 })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min="0"
                    />
                  </div>
                </div>
              </div>

              {/* Salary Components */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Salary Components</h3>

                {loading && (
                  <div className="text-center py-4">
                    <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    <p className="text-sm text-gray-600 mt-2">Calculating year-to-date values...</p>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Earnings */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Earnings</h4>
                    <div className="space-y-2">
                      <div className="grid grid-cols-12 gap-3 items-center text-xs font-medium text-gray-500 uppercase">
                        <div className="col-span-6">Component</div>
                        <div className="col-span-3">Monthly</div>
                        <div className="col-span-3">Year to Date</div>
                      </div>
                      {salaryComponents.filter(comp => comp.type === 'earning').map((component) => (
                        <div key={component.id} className="grid grid-cols-12 gap-3 items-center">
                          <div className="col-span-6">
                            <span className="text-sm font-medium text-gray-900">{component.name}</span>
                          </div>
                          <div className="col-span-3">
                            <input
                              type="number"
                              value={component.monthly}
                              onChange={(e) => handleComponentChange(component.id, 'monthly', parseFloat(e.target.value) || 0)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            />
                          </div>
                          <div className="col-span-3">
                            <div className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">
                              {component.ytd.toLocaleString('en-IN')}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Deductions */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Deductions</h4>
                    <div className="space-y-2">
                      <div className="grid grid-cols-12 gap-3 items-center text-xs font-medium text-gray-500 uppercase">
                        <div className="col-span-6">Component</div>
                        <div className="col-span-3">Monthly</div>
                        <div className="col-span-3">Year to Date</div>
                      </div>
                      {salaryComponents.filter(comp => comp.type === 'deduction').map((component) => (
                        <div key={component.id} className="grid grid-cols-12 gap-3 items-center">
                          <div className="col-span-6">
                            <span className="text-sm font-medium text-gray-900">{component.name}</span>
                          </div>
                          <div className="col-span-3">
                            <input
                              type="number"
                              value={component.monthly}
                              onChange={(e) => handleComponentChange(component.id, 'monthly', parseFloat(e.target.value) || 0)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            />
                          </div>
                          <div className="col-span-3">
                            <div className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700">
                              {component.ytd.toLocaleString('en-IN')}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Total Earnings (A)</span>
                    <span className="text-sm font-bold text-green-600">₹{totalEarnings.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Total Deductions (B)</span>
                    <span className="text-sm font-bold text-red-600">₹{totalDeductions.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-gray-200 pt-2">
                    <span className="text-sm font-bold text-gray-900">Net Payable (A-B)</span>
                    <span className="text-sm font-bold text-blue-600">₹{netPayable.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-6">
                  <button
                    onClick={handleGeneratePayslip}
                    disabled={!month || salaryComponents.length === 0 || loading || 
                             (selectedEmployee && !isValidMonthYear(selectedEmployee, month, year)) ||
                             isFutureMonthYear(month, year)}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    {loading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <Calculator className="h-5 w-5" />
                        <span>Generate Payslip</span>
                      </>
                    )}
                  </button>
                  {selectedEmployee && month && !isValidMonthYear(selectedEmployee, month, year) && (
                    <p className="text-xs text-red-500 mt-2 text-center">
                      Cannot generate payslip for months before employee's joining date
                    </p>
                  )}
                  {month && isFutureMonthYear(month, year) && (
                    <p className="text-xs text-red-500 mt-2 text-center">
                      Cannot generate payslip for future months beyond next month
                    </p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Preview Modal */}
      {showPreview && selectedEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Payslip Preview</h2>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              <PayslipTemplate
                employee={{ ...selectedEmployee, ...payslipData }}
                month={month}
                year={year}
                salaryComponents={salaryComponents}
                totalEarnings={totalEarnings}
                totalDeductions={totalDeductions}
                netPayable={netPayable}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}