import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Plus, Edit2, Trash2, Search, Download, Upload, Eye, Check, X } from 'lucide-react';
import { Employee, CTCComponent, SalaryStructureComponent } from '../types';

export default function Employees() {
  const { state, dispatch, saveEmployee, deleteEmployee } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [pendingEmployees, setPendingEmployees] = useState<Employee[]>([]);
  const [showPreview, setShowPreview] = useState(false);

  const filteredEmployees = state.employees.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.empCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.designation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddEmployee = () => {
    setEditingEmployee(null);
    setShowAddModal(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setEditingEmployee(employee);
    setShowAddModal(true);
  };

  const handleDeleteEmployee = async (employeeId: string) => {
    if (window.confirm('Are you sure you want to delete this employee? This will also remove all their salary records.')) {
      try {
        await deleteEmployee(employeeId);
        alert('Employee deleted successfully');
      } catch (error) {
        console.error('Error deleting employee:', error);
        alert('Error deleting employee. Please try again.');
      }
    }
  };

  const handleAddToPending = (employee: Employee) => {
    const newEmployee = { ...employee, id: `pending_${Date.now()}_${Math.random().toString(36).substr(2, 9)}` };
    setPendingEmployees(prev => [...prev, newEmployee]);
    setShowAddModal(false);
  };

  const handleUpdatePending = (employee: Employee) => {
    setPendingEmployees(prev => 
      prev.map(emp => emp.id === employee.id ? employee : emp)
    );
    setShowAddModal(false);
  };

  const handleRemoveFromPending = (employeeId: string) => {
    setPendingEmployees(prev => prev.filter(emp => emp.id !== employeeId));
  };

  const handleSubmitAllEmployees = async () => {
    if (pendingEmployees.length === 0) return;

    let successCount = 0;
    let errorCount = 0;
    const errors: string[] = [];

    try {
      // Save all pending employees to database
      for (const employee of pendingEmployees) {
        try {
          await saveEmployee(employee);
          successCount++;
        } catch (error) {
          errorCount++;
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          errors.push(`${employee.name} (${employee.empCode}): ${errorMessage}`);
        }
      }

      // Clear pending employees
      setPendingEmployees([]);
      setShowPreview(false);
      
      if (successCount > 0) {
        alert(`${successCount} employee(s) added successfully!${errorCount > 0 ? `\n\n${errorCount} failed:\n${errors.join('\n')}` : ''}`);
      } else {
        alert(`All employees failed to save:\n${errors.join('\n')}`);
      }
    } catch (error) {
      console.error('Error submitting employees:', error);
      alert('Error adding employees. Please try again.');
    }
  };

  const handleDirectSave = async (employee: Employee) => {
    try {
      if (editingEmployee) {
        await saveEmployee(employee);
        alert('Employee updated successfully!');
      } else {
        await saveEmployee(employee);
        alert('Employee added successfully!');
      }
      setShowAddModal(false);
    } catch (error) {
      console.error('Error saving employee:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      alert(`Error saving employee: ${errorMessage}`);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Employee Management</h1>
          <p className="text-gray-600">Manage employee information and salary structures</p>
        </div>
        <div className="flex items-center space-x-3">
          {pendingEmployees.length > 0 && (
            <button 
              onClick={() => setShowPreview(true)}
              className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
            >
              <Eye className="h-4 w-4" />
              <span>Preview ({pendingEmployees.length})</span>
            </button>
          )}
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
            <Upload className="h-4 w-4" />
            <span>Import CSV</span>
          </button>
          <button 
            onClick={handleAddEmployee}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option>All Locations</option>
            <option>Nashik</option>
            <option>Mumbai</option>
            <option>Pune</option>
          </select>
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option>All Types</option>
            <option>Full Time</option>
            <option>Part Time</option>
            <option>Contract</option>
          </select>
        </div>
      </div>

      {/* Loading State */}
      {state.loading && (
        <div className="text-center py-8">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <p className="text-gray-600 mt-2">Loading employees...</p>
        </div>
      )}

      {/* Employee Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Code
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Designation
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  CTC (Annual)
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  DOJ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredEmployees.map((employee) => {
                const totalCTC = employee.ctcStructure?.reduce((sum, comp) => sum + comp.perAnnum, 0) || 0;
                return (
                  <tr key={employee.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                        <div className="text-sm text-gray-500">{employee.email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {employee.empCode}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {employee.designation}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {employee.location}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                        {employee.empType}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ₹{totalCTC.toLocaleString('en-IN')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {employee.doj ? new Date(employee.doj).toLocaleDateString() : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEditEmployee(employee)}
                          className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteEmployee(employee.id)}
                          className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {!state.loading && filteredEmployees.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500">
              {searchTerm ? 'No employees found matching your search.' : 'No employees found. Add your first employee to get started.'}
            </div>
          </div>
        )}
      </div>

      {/* Add/Edit Employee Modal */}
      {showAddModal && (
        <EmployeeModal
          employee={editingEmployee}
          onClose={() => setShowAddModal(false)}
          onSave={handleDirectSave}
          onAddToPreview={handleAddToPending}
          isEditing={!!editingEmployee}
        />
      )}

      {/* Preview Modal */}
      {showPreview && (
        <PreviewModal
          employees={pendingEmployees}
          onClose={() => setShowPreview(false)}
          onSubmit={handleSubmitAllEmployees}
          onEdit={(employee) => {
            setEditingEmployee(employee);
            setShowAddModal(true);
            setShowPreview(false);
          }}
          onRemove={handleRemoveFromPending}
        />
      )}
    </div>
  );
}

function PreviewModal({
  employees,
  onClose,
  onSubmit,
  onEdit,
  onRemove,
}: {
  employees: Employee[];
  onClose: () => void;
  onSubmit: () => void;
  onEdit: (employee: Employee) => void;
  onRemove: (employeeId: string) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">
              Preview Employees ({employees.length})
            </h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          <p className="text-gray-600 mt-2">
            Review the employees below before submitting to the database.
          </p>
        </div>

        <div className="p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Employee
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Code
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Designation
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Location
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    CTC (Annual)
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {employees.map((employee) => {
                  const totalCTC = employee.ctcStructure?.reduce((sum, comp) => sum + comp.perAnnum, 0) || 0;
                  return (
                    <tr key={employee.id} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                          <div className="text-sm text-gray-500">{employee.email}</div>
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {employee.empCode}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {employee.designation}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {employee.location}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₹{totalCTC.toLocaleString('en-IN')}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => onEdit(employee)}
                            className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => onRemove(employee.id)}
                            className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onSubmit}
              disabled={employees.length === 0}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              <Check className="h-4 w-4" />
              <span>Submit All Employees ({employees.length})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmployeeModal({ 
  employee, 
  onClose, 
  onSave,
  onAddToPreview,
  isEditing
}: { 
  employee: Employee | null; 
  onClose: () => void; 
  onSave: (employee: Employee) => void;
  onAddToPreview: (employee: Employee) => void;
  isEditing: boolean;
}) {
  const [activeTab, setActiveTab] = useState('basic');
  const [formData, setFormData] = useState<Partial<Employee>>(
    employee || {
      name: '',
      empCode: '',
      designation: '',
      empType: 'Full Time',
      location: '',
      uan: '',
      pan: '',
      pfNumber: '',
      doj: '',
      email: '',
      ctcStructure: [
        { id: '1', name: 'Basic Pay', perMonth: 0, perAnnum: 0 },
        { id: '2', name: 'House Rent allowance', perMonth: 0, perAnnum: 0 },
        { id: '3', name: 'Special Allowances', perMonth: 0, perAnnum: 0 },
        { id: '4', name: 'Conveyance', perMonth: 0, perAnnum: 0 },
        { id: '5', name: 'Leave Travel Allowance (LTA)', perMonth: 0, perAnnum: 0 },
      ],
      salaryStructure: [
        { id: '1', name: 'Basic Pay', currentMonth: 0, type: 'earning' },
        { id: '2', name: 'House Rent allowance', currentMonth: 0, type: 'earning' },
        { id: '3', name: 'Special Allowances', currentMonth: 0, type: 'earning' },
        { id: '4', name: 'Conveyance', currentMonth: 0, type: 'earning' },
        { id: '5', name: 'Leave Travel Allowance (LTA)', currentMonth: 0, type: 'earning' },
        { id: '6', name: 'PF', currentMonth: 0, type: 'deduction' },
        { id: '7', name: 'Professional Tax', currentMonth: 0, type: 'deduction' },
      ],
    }
  );

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name?.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.empCode?.trim()) {
      newErrors.empCode = 'Employee Code is required';
    }

    if (!formData.email?.trim()) {
      newErrors.email = 'Email is required';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }
    }

    if (!formData.designation?.trim()) {
      newErrors.designation = 'Designation is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSave(formData as Employee);
    }
  };

  const handleAddToPreview = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onAddToPreview(formData as Employee);
    }
  };

  const updateCTCComponent = (id: string, field: keyof CTCComponent, value: number | string) => {
    setFormData(prev => ({
      ...prev,
      ctcStructure: prev.ctcStructure?.map(comp =>
        comp.id === id ? { ...comp, [field]: value } : comp
      ) || []
    }));
  };

  const updateSalaryComponent = (id: string, field: keyof SalaryStructureComponent, value: number | string) => {
    setFormData(prev => ({
      ...prev,
      salaryStructure: prev.salaryStructure?.map(comp =>
        comp.id === id ? { ...comp, [field]: value } : comp
      ) || []
    }));
  };

  const addCTCComponent = () => {
    const newComponent: CTCComponent = {
      id: Date.now().toString(),
      name: '',
      perMonth: 0,
      perAnnum: 0,
    };
    setFormData(prev => ({
      ...prev,
      ctcStructure: [...(prev.ctcStructure || []), newComponent]
    }));
  };

  const addSalaryComponent = () => {
    const newComponent: SalaryStructureComponent = {
      id: Date.now().toString(),
      name: '',
      currentMonth: 0,
      type: 'earning',
    };
    setFormData(prev => ({
      ...prev,
      salaryStructure: [...(prev.salaryStructure || []), newComponent]
    }));
  };

  const removeCTCComponent = (id: string) => {
    setFormData(prev => ({
      ...prev,
      ctcStructure: prev.ctcStructure?.filter(comp => comp.id !== id) || []
    }));
  };

  const removeSalaryComponent = (id: string) => {
    setFormData(prev => ({
      ...prev,
      salaryStructure: prev.salaryStructure?.filter(comp => comp.id !== id) || []
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">
            {employee ? 'Edit Employee' : 'Add New Employee'}
          </h2>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('basic')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'basic'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Basic Information
            </button>
            <button
              onClick={() => setActiveTab('ctc')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'ctc'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              CTC Structure
            </button>
            <button
              onClick={() => setActiveTab('salary')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'salary'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Salary Structure
            </button>
          </nav>
        </div>
        
        <div className="p-6">
          {activeTab === 'basic' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee Name *
                </label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.name ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee Code *
                </label>
                <input
                  type="text"
                  value={formData.empCode || ''}
                  onChange={(e) => setFormData({ ...formData, empCode: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.empCode ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.empCode && <p className="text-red-500 text-xs mt-1">{errors.empCode}</p>}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Designation *
                </label>
                <input
                  type="text"
                  value={formData.designation || ''}
                  onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.designation ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.designation && <p className="text-red-500 text-xs mt-1">{errors.designation}</p>}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee Type *
                </label>
                <select
                  value={formData.empType || 'Full Time'}
                  onChange={(e) => setFormData({ ...formData, empType: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Full Time">Full Time</option>
                  <option value="Part Time">Part Time</option>
                  <option value="Contract">Contract</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Location
                </label>
                <input
                  type="text"
                  value={formData.location || ''}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  value={formData.email || ''}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.email ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  UAN
                </label>
                <input
                  type="text"
                  value={formData.uan || ''}
                  onChange={(e) => setFormData({ ...formData, uan: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PAN
                </label>
                <input
                  type="text"
                  value={formData.pan || ''}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PF Number
                </label>
                <input
                  type="text"
                  value={formData.pfNumber || ''}
                  onChange={(e) => setFormData({ ...formData, pfNumber: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date of Joining
                </label>
                <input
                  type="date"
                  value={formData.doj || ''}
                  onChange={(e) => setFormData({ ...formData, doj: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          )}

          {activeTab === 'ctc' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">CTC Structure</h3>
                <button
                  type="button"
                  onClick={addCTCComponent}
                  className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-1 text-sm"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Component</span>
                </button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border border-gray-200 rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Component Name</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Per Month</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Per Annum</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {formData.ctcStructure?.map((component) => (
                      <tr key={component.id} className="border-t border-gray-200">
                        <td className="px-4 py-2">
                          <input
                            type="text"
                            value={component.name}
                            onChange={(e) => updateCTCComponent(component.id, 'name', e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                            placeholder="Component name"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            type="number"
                            value={component.perMonth}
                            onChange={(e) => updateCTCComponent(component.id, 'perMonth', parseFloat(e.target.value) || 0)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <input
                            type="number"
                            value={component.perAnnum}
                            onChange={(e) => updateCTCComponent(component.id, 'perAnnum', parseFloat(e.target.value) || 0)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <button
                            type="button"
                            onClick={() => removeCTCComponent(component.id)}
                            className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'salary' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">Salary Structure</h3>
                <button
                  type="button"
                  onClick={addSalaryComponent}
                  className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-1 text-sm"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Component</span>
                </button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border border-gray-200 rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Component Name</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Type</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Current Month</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {formData.salaryStructure?.map((component) => (
                      <tr key={component.id} className="border-t border-gray-200">
                        <td className="px-4 py-2">
                          <input
                            type="text"
                            value={component.name}
                            onChange={(e) => updateSalaryComponent(component.id, 'name', e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                            placeholder="Component name"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <select
                            value={component.type}
                            onChange={(e) => updateSalaryComponent(component.id, 'type', e.target.value as 'earning' | 'deduction')}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                          >
                            <option value="earning">Earning</option>
                            <option value="deduction">Deduction</option>
                          </select>
                        </td>
                        <td className="px-4 py-2">
                          <input
                            type="number"
                            value={component.currentMonth}
                            onChange={(e) => updateSalaryComponent(component.id, 'currentMonth', parseFloat(e.target.value) || 0)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                          />
                        </td>
                        <td className="px-4 py-2">
                          <button
                            type="button"
                            onClick={() => removeSalaryComponent(component.id)}
                            className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            {!isEditing && (
              <button
                onClick={handleAddToPreview}
                className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
              >
                Add to Preview
              </button>
            )}
            <button
              onClick={handleSubmit}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              {isEditing ? 'Update Employee' : 'Save Directly'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}