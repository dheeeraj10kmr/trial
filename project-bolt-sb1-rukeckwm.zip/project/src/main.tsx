import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { testConnection } from './lib/supabase';

// Test Supabase connection on app start
testConnection().then(connected => {
  if (!connected) {
    console.warn('Supabase connection failed. Please check your configuration.');
  }
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);