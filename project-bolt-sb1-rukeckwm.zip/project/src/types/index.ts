export interface Employee {
  id: string;
  name: string;
  empCode: string;
  designation: string;
  empType: string;
  location: string;
  uan: string;
  pan: string;
  pfNumber: string;
  doj: string;
  lwd?: string;
  email: string;
  ctcStructure: CTCComponent[];
  salaryStructure: SalaryStructureComponent[];
}

export interface CTCComponent {
  id: string;
  name: string;
  perMonth: number;
  perAnnum: number;
}

export interface SalaryStructureComponent {
  id: string;
  name: string;
  currentMonth: number;
  type: 'earning' | 'deduction';
}

export interface SalaryComponent {
  id: string;
  name: string;
  monthly: number;
  ytd: number;
  type: 'earning' | 'deduction';
}

export interface PayslipData {
  paidDays: number;
  leaveEncashmentDays: number;
  noticePay: number;
}

export interface Payslip {
  id: string;
  employeeId: string;
  month: string;
  year: number;
  salaryComponents: SalaryComponent[];
  payslipData: PayslipData;
  totalEarnings: number;
  totalDeductions: number;
  netPayable: number;
  generatedDate: string;
  status: 'draft' | 'generated' | 'sent';
}

export interface EmailConfig {
  fromEmail: string;
  toEmail: string;
  subject: string;
  cc?: string;
  bcc?: string;
  template: string;
}

export interface Schedule {
  id: string;
  employeeIds: string[];
  month: string;
  year: number;
  dayOfMonth: number;
  time: string;
  active: boolean;
  lastRun?: string;
  nextRun: string;
}

export interface EmailLog {
  id: string;
  payslipId: string;
  employeeId: string;
  employeeName: string;
  fromEmail: string;
  toEmail: string;
  sentDate: string;
  status: 'success' | 'failed' | 'pending';
  errorMessage?: string;
}

export interface EmpSalary {
  id: string;
  employeeId: string;
  month: string;
  year: number;
  componentId: string;
  componentName: string;
  amount: number;
  type: 'earning' | 'deduction';
  createdDate: string;
}