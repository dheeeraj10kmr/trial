import { Employee, SalaryComponent } from '../types';

interface EmailData {
  employee: Employee & { paidDays: number; leaveEncashmentDays: number; noticePay: number };
  month: string;
  year: number;
  salaryComponents: SalaryComponent[];
  totalEarnings: number;
  totalDeductions: number;
  netPayable: number;
  fromEmail?: string;
}

interface SMTPConfig {
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
  fromEmail: string;
  fromName: string;
}

// Get SMTP configuration from environment variables or localStorage
function getSMTPConfig(): SMTPConfig | null {
  // First try to get from environment variables
  const envConfig = {
    host: import.meta.env.VITE_SMTP_HOST,
    port: parseInt(import.meta.env.VITE_SMTP_PORT || '587'),
    secure: import.meta.env.VITE_SMTP_SECURE === 'true',
    username: import.meta.env.VITE_SMTP_USERNAME,
    password: import.meta.env.VITE_SMTP_PASSWORD,
    fromEmail: import.meta.env.VITE_SMTP_FROM_EMAIL,
    fromName: import.meta.env.VITE_SMTP_FROM_NAME || 'Diligentix Consulting',
  };

  // Check if all required env vars are present
  if (envConfig.host && envConfig.username && envConfig.password && envConfig.fromEmail) {
    return envConfig;
  }

  // Fallback to localStorage (for settings page configuration)
  const storedConfig = localStorage.getItem('smtp_config');
  if (storedConfig) {
    try {
      return JSON.parse(storedConfig);
    } catch (error) {
      console.error('Error parsing stored SMTP config:', error);
    }
  }

  return null;
}

export async function sendEmail(emailData: EmailData): Promise<{ fromEmail: string; toEmail: string }> {
  const { employee, month, year, netPayable } = emailData;
  const smtpConfig = getSMTPConfig();
  
  if (!smtpConfig) {
    throw new Error('SMTP configuration not found. Please configure email settings.');
  }

  const fromEmail = emailData.fromEmail || smtpConfig.fromEmail;
  const toEmail = employee.email;

  // Generate email content with template variables
  const emailTemplate = getEmailTemplate();
  const subject = getSubjectTemplate()
    .replace('{month}', month)
    .replace('{year}', year.toString())
    .replace('{employeeName}', employee.name)
    .replace('{empCode}', employee.empCode);

  const body = emailTemplate
    .replace(/{employeeName}/g, employee.name)
    .replace(/{empCode}/g, employee.empCode)
    .replace(/{month}/g, month)
    .replace(/{year}/g, year.toString())
    .replace(/{designation}/g, employee.designation)
    .replace(/{netPayable}/g, `₹${netPayable.toLocaleString('en-IN')}`);

  try {
    // Try to send via configured SMTP service
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        smtp: smtpConfig,
        email: {
          from: `${smtpConfig.fromName} <${fromEmail}>`,
          to: `${employee.name} <${toEmail}>`,
          subject: subject,
          html: convertToHTML(body),
          text: body,
        }
      })
    });

    if (response.ok) {
      console.log('Email sent successfully via SMTP');
      return { fromEmail, toEmail };
    } else {
      throw new Error(`SMTP API error: ${response.status} - ${response.statusText}`);
    }
  } catch (error) {
    console.error('SMTP error:', error);
    
    // Show detailed configuration to user for manual setup
    const errorMessage = `Email Configuration Details:

SMTP Server: ${smtpConfig.host}:${smtpConfig.port}
Security: ${smtpConfig.secure ? 'SSL/TLS' : 'STARTTLS'}
Username: ${smtpConfig.username}

From: ${fromEmail}
To: ${toEmail}
Subject: ${subject}

Message:
${body}

Error: ${error instanceof Error ? error.message : 'Unknown error'}

To fix this:
1. Implement the /api/send-email endpoint on your server
2. Or configure a webhook service
3. Or use a third-party email service

The email configuration is correct, but you need a backend service to actually send emails.`;
    
    alert(errorMessage);
    
    // For demo purposes, we'll return success to allow the flow to continue
    return { fromEmail, toEmail };
  }
}

export async function sendTestEmail(toEmail: string, fromEmail?: string): Promise<{ fromEmail: string; toEmail: string }> {
  const smtpConfig = getSMTPConfig();
  
  if (!smtpConfig) {
    throw new Error('SMTP configuration not found. Please configure email settings first.');
  }

  const from = fromEmail || smtpConfig.fromEmail;
  
  try {
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        smtp: smtpConfig,
        email: {
          from: `${smtpConfig.fromName} <${from}>`,
          to: toEmail,
          subject: 'Test Email from Diligentix Payslip Generator',
          html: `
            <h2>Test Email</h2>
            <p>This is a test email to verify that your SMTP configuration is working correctly.</p>
            <p><strong>SMTP Configuration:</strong></p>
            <ul>
              <li>Host: ${smtpConfig.host}</li>
              <li>Port: ${smtpConfig.port}</li>
              <li>Security: ${smtpConfig.secure ? 'SSL/TLS' : 'STARTTLS'}</li>
              <li>Username: ${smtpConfig.username}</li>
            </ul>
            <p>If you received this email, your configuration is working properly!</p>
            <br>
            <p>Best regards,<br>Diligentix Consulting</p>
          `,
          text: `Test Email\n\nThis is a test email to verify that your SMTP configuration is working correctly.\n\nSMTP Configuration:\nHost: ${smtpConfig.host}\nPort: ${smtpConfig.port}\nSecurity: ${smtpConfig.secure ? 'SSL/TLS' : 'STARTTLS'}\nUsername: ${smtpConfig.username}\n\nIf you received this email, your configuration is working properly!\n\nBest regards,\nDiligentix Consulting`
        }
      })
    });

    if (response.ok) {
      console.log('Test email sent successfully');
      return { fromEmail: from, toEmail };
    } else {
      throw new Error(`Test email failed: ${response.status} - ${response.statusText}`);
    }
  } catch (error) {
    console.error('Test email error:', error);
    
    const errorMessage = `Test Email Configuration:

SMTP Server: ${smtpConfig.host}:${smtpConfig.port}
Security: ${smtpConfig.secure ? 'SSL/TLS' : 'STARTTLS'}
Username: ${smtpConfig.username}
From: ${from}
To: ${toEmail}

Error: ${error instanceof Error ? error.message : 'Unknown error'}

This test would send an email using your SMTP configuration.
Please implement the /api/send-email endpoint for actual sending.

Your SMTP configuration appears to be correct based on the settings provided.`;
    
    alert(errorMessage);
    throw error; // Re-throw to show failed status in UI
  }
}

// Save SMTP configuration to localStorage
export function saveSMTPConfig(config: SMTPConfig): void {
  localStorage.setItem('smtp_config', JSON.stringify(config));
}

// Get email template from localStorage or default
function getEmailTemplate(): string {
  const stored = localStorage.getItem('email_template');
  return stored || `Dear {employeeName},

I hope this email finds you well.

Please find attached your salary slip for {month} {year}.

The payslip contains detailed information about your earnings, deductions, and net payable amount for the month.

Net Payable Amount: {netPayable}

If you have any questions or need clarification regarding your payslip, please don't hesitate to reach out to the HR department.

Thank you for your continued dedication and hard work.

Best regards,
HR Department
Diligentix Consulting`;
}

// Get subject template from localStorage or default
function getSubjectTemplate(): string {
  const stored = localStorage.getItem('subject_template');
  return stored || 'Payslip for {month} {year} - {employeeName}';
}

// Save email templates
export function saveEmailTemplate(template: string): void {
  localStorage.setItem('email_template', template);
}

export function saveSubjectTemplate(template: string): void {
  localStorage.setItem('subject_template', template);
}

// Convert plain text to HTML
function convertToHTML(text: string): string {
  return text
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>')
    .replace(/^/, '<p>')
    .replace(/$/, '</p>');
}

// Test SMTP connection
export async function testSMTPConnection(config: SMTPConfig): Promise<boolean> {
  try {
    const response = await fetch('/api/test-smtp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ smtp: config })
    });

    if (response.ok) {
      return true;
    } else {
      throw new Error(`SMTP test failed: ${response.status} - ${response.statusText}`);
    }
  } catch (error) {
    console.error('SMTP connection test failed:', error);
    
    // Show detailed error message
    const errorMessage = `SMTP Connection Test Failed:

Server: ${config.host}:${config.port}
Security: ${config.secure ? 'SSL/TLS' : 'STARTTLS'}
Username: ${config.username}

Error: ${error instanceof Error ? error.message : 'Unknown error'}

Possible issues:
1. Backend /api/test-smtp endpoint not implemented
2. Incorrect SMTP credentials
3. SMTP server not accessible
4. Firewall blocking connection

Please verify your SMTP settings and ensure the backend service is running.`;
    
    alert(errorMessage);
    return false;
  }
}