import { supabase } from '../lib/supabase';
import { EmpSalary, Employee, SalaryComponent } from '../types';

export async function saveEmpSalary(data: Omit<EmpSalary, 'id' | 'createdDate'>): Promise<EmpSalary> {
  try {
    const { data: result, error } = await supabase
      .from('empsalary')
      .insert([{
        emp_code: data.employeeId, // Now using emp_code instead of employee_id
        month: data.month,
        year: data.year,
        component_id: data.componentId,
        component_name: data.componentName,
        amount: data.amount,
        type: data.type,
        created_at: new Date().toISOString() // Changed from created_date to created_at
      }])
      .select()
      .single();

    if (error) {
      console.error('Error saving to Supabase:', error);
      throw error;
    }

    return {
      id: result.id,
      employeeId: result.emp_code, // Using emp_code
      month: result.month,
      year: result.year,
      componentId: result.component_id,
      componentName: result.component_name,
      amount: result.amount,
      type: result.type,
      createdDate: result.created_at // Changed from created_date to created_at
    };
  } catch (error) {
    console.error('Database error:', error);
    throw error;
  }
}

export async function getEmpSalaryHistory(
  empCode: string, // Changed from employeeId to empCode
  componentId: string,
  fromMonth: string,
  fromYear: number,
  toMonth: string,
  toYear: number
): Promise<EmpSalary[]> {
  try {
    const { data, error } = await supabase
      .from('empsalary')
      .select('*')
      .eq('emp_code', empCode) // Using emp_code instead of employee_id
      .eq('component_id', componentId)
      .gte('year', fromYear)
      .lte('year', toYear);

    if (error) {
      console.error('Error fetching from Supabase:', error);
      return [];
    }

    // Filter by month range within the year
    const filteredData = data.filter(record => {
      const recordMonthIndex = getMonthIndex(record.month);
      const fromMonthIndex = getMonthIndex(fromMonth);
      const toMonthIndex = getMonthIndex(toMonth);
      
      if (record.year === fromYear && record.year === toYear) {
        return recordMonthIndex >= fromMonthIndex && recordMonthIndex <= toMonthIndex;
      } else if (record.year === fromYear) {
        return recordMonthIndex >= fromMonthIndex;
      } else if (record.year === toYear) {
        return recordMonthIndex <= toMonthIndex;
      } else {
        return true; // Years in between
      }
    });

    return filteredData.map(record => ({
      id: record.id,
      employeeId: record.emp_code, // Using emp_code
      month: record.month,
      year: record.year,
      componentId: record.component_id,
      componentName: record.component_name,
      amount: record.amount,
      type: record.type,
      createdDate: record.created_at // Changed from created_date to created_at
    }));
  } catch (error) {
    console.error('Database error:', error);
    return [];
  }
}

export async function calculateYearToDate(
  employee: Employee,
  month: string,
  year: number
): Promise<SalaryComponent[]> {
  const monthIndex = getMonthIndex(month);
  const aprilIndex = 3; // April is index 3 (0-based)
  
  // Determine the financial year start
  let startYear = year;
  let startMonth = 'April';
  
  if (monthIndex < aprilIndex) {
    startYear = year - 1;
  }

  const components: SalaryComponent[] = [];

  for (const component of employee.salaryStructure) {
    try {
      // Get historical data from database using emp_code
      const history = await getEmpSalaryHistory(
        employee.empCode, // Using empCode instead of id
        component.id,
        startMonth,
        startYear,
        month,
        year
      );

      let ytdAmount = 0;
      
      if (history.length > 0) {
        // Calculate YTD from actual database records
        ytdAmount = history.reduce((sum, record) => sum + record.amount, 0);
        
        // Add current month if not already in history
        const currentMonthExists = history.some(record => 
          record.month === month && record.year === year
        );
        
        if (!currentMonthExists) {
          ytdAmount += component.currentMonth;
        }
      } else {
        // If no history exists, YTD is just the current month amount
        // This prevents incorrect calculation for first-time payslip generation
        ytdAmount = component.currentMonth;
      }

      components.push({
        id: component.id,
        name: component.name,
        monthly: component.currentMonth,
        ytd: ytdAmount,
        type: component.type,
      });
    } catch (error) {
      console.error(`Error calculating YTD for component ${component.name}:`, error);
      // Fallback: use current month amount only
      components.push({
        id: component.id,
        name: component.name,
        monthly: component.currentMonth,
        ytd: component.currentMonth,
        type: component.type,
      });
    }
  }

  return components;
}

function getMonthIndex(monthName: string): number {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months.indexOf(monthName);
}

export async function savePayslipToDatabase(
  employee: Employee,
  month: string,
  year: number,
  salaryComponents: SalaryComponent[]
): Promise<void> {
  try {
    // Check if payslip already exists for this employee, month, and year
    const { data: existingRecords } = await supabase
      .from('empsalary')
      .select('id')
      .eq('emp_code', employee.empCode) // Using emp_code
      .eq('month', month)
      .eq('year', year);

    if (existingRecords && existingRecords.length > 0) {
      // Delete existing records for this month/year
      await supabase
        .from('empsalary')
        .delete()
        .eq('emp_code', employee.empCode) // Using emp_code
        .eq('month', month)
        .eq('year', year);
    }

    // Save each salary component to the database
    for (const component of salaryComponents) {
      await saveEmpSalary({
        employeeId: employee.empCode, // Using empCode instead of id
        month,
        year,
        componentId: component.id,
        componentName: component.name,
        amount: component.monthly,
        type: component.type,
      });
    }
    console.log('Payslip data saved to Supabase successfully');
  } catch (error) {
    console.error('Error saving payslip to database:', error);
    throw error;
  }
}

// Initialize database tables
export async function initializeDatabase() {
  try {
    console.log('Database initialization completed');
  } catch (error) {
    console.log('Database initialization completed');
  }
}