import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Employee, SalaryComponent } from '../types';

interface PayslipData {
  employee: Employee;
  month: string;
  year: number;
  salaryComponents: SalaryComponent[];
  totalEarnings: number;
  totalDeductions: number;
  netPayable: number;
}

export async function generatePDF(payslipData: PayslipData): Promise<void> {
  const { employee, month, year } = payslipData;
  
  // Create a temporary div with the payslip content
  const tempDiv = document.createElement('div');
  tempDiv.style.position = 'absolute';
  tempDiv.style.left = '-9999px';
  tempDiv.style.width = '794px'; // A4 width in pixels at 96 DPI
  tempDiv.style.backgroundColor = 'white';
  tempDiv.style.padding = '40px';
  tempDiv.style.fontFamily = 'Arial, sans-serif';
  
  tempDiv.innerHTML = generatePayslipHTML(payslipData);
  document.body.appendChild(tempDiv);

  try {
    // Convert to canvas
    const canvas = await html2canvas(tempDiv, {
      scale: 2,
      useCORS: true,
      backgroundColor: '#ffffff',
      width: 794,
      height: 1123, // A4 height in pixels
    });

    // Create PDF
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgWidth = 210; // A4 width in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, imgWidth, imgHeight);
    
    // Download the PDF
    const filename = `${employee.empCode}_Payslip_${month}_${year}.pdf`;
    pdf.save(filename);
  } finally {
    // Clean up
    document.body.removeChild(tempDiv);
  }
}

function generatePayslipHTML(data: PayslipData): string {
  const { employee, month, year, salaryComponents, totalEarnings, totalDeductions, netPayable } = data;
  
  const earnings = salaryComponents.filter(comp => comp.type === 'earning');
  const deductions = salaryComponents.filter(comp => comp.type === 'deduction');
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  return `
    <div style="font-family: Arial, sans-serif; max-width: 794px; margin: 0 auto; background: white;">
      <!-- Header -->
      <div style="border-bottom: 3px solid #2563eb; padding-bottom: 24px; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div style="display: flex; align-items: center;">
            <div style="width: 64px; height: 64px; background: #2563eb; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 16px; position: relative;">
              <img 
                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
                alt="Diligentix Logo" 
                style="width: 48px; height: 48px; object-fit: contain; display: none;"
                onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"
              />
              <span style="color: white; font-weight: bold; font-size: 24px;">DC</span>
            </div>
            <div>
              <h1 style="font-size: 28px; font-weight: bold; color: #111827; margin: 0 0 4px 0;">Diligentix Consulting</h1>
              <p style="font-size: 14px; color: #6b7280; margin: 0;">Payslip for ${month} ${year}</p>
            </div>
          </div>
          <div style="text-align: right; font-size: 12px; color: #6b7280; line-height: 1.4;">
            <p style="margin: 0;">Office No. 6571/6572/17,</p>
            <p style="margin: 0;">Viman Nagar, Nashik-422207,</p>
            <p style="margin: 0;">Maharashtra, India.</p>
            <p style="margin: 0;">CIN: U62099MH2024OPC436737</p>
          </div>
        </div>
      </div>

      <!-- Employee Information -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-bottom: 32px;">
        <div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Employee Name:</span>
            <span style="color: #111827;">${employee.name}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Emp Code:</span>
            <span style="color: #111827;">${employee.empCode}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Designation:</span>
            <span style="color: #111827;">${employee.designation}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Emp Type:</span>
            <span style="color: #111827;">${employee.empType}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Location:</span>
            <span style="color: #111827;">${employee.location}</span>
          </div>
        </div>
        
        <div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">UAN:</span>
            <span style="color: #111827;">${employee.uan}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">PAN:</span>
            <span style="color: #111827;">${employee.pan}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">PF Number:</span>
            <span style="color: #111827;">${employee.pfNumber}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">DOJ:</span>
            <span style="color: #111827;">${new Date(employee.doj).toLocaleDateString('en-IN')}</span>
          </div>
          <div style="margin-bottom: 12px;">
            <span style="font-weight: 600; color: #374151; display: inline-block; width: 120px;">Paid Days:</span>
            <span style="color: #111827;">${employee.paidDays}</span>
          </div>
        </div>
      </div>

      <!-- Salary Details -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-bottom: 32px;">
        <!-- Earnings -->
        <div>
          <h3 style="font-size: 18px; font-weight: 600; color: #111827; margin-bottom: 16px; background: #dcfce7; padding: 12px; border-radius: 8px;">
            Earnings
          </h3>
          <div>
            <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 12px; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px; margin-bottom: 8px;">
              <span>Component</span>
              <span>Amount (₹)</span>
            </div>
            ${earnings.map(component => `
              <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 14px; margin-bottom: 8px;">
                <span style="color: #111827;">${component.name}</span>
                <span style="color: #111827;">${component.monthly.toLocaleString('en-IN')}</span>
              </div>
            `).join('')}
            <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 14px; font-weight: bold; border-top: 1px solid #e5e7eb; padding-top: 8px; background: #dcfce7; padding: 8px; border-radius: 4px;">
              <span style="color: #166534;">Total Earnings (A)</span>
              <span style="color: #166534;">${totalEarnings.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <!-- Deductions -->
        <div>
          <h3 style="font-size: 18px; font-weight: 600; color: #111827; margin-bottom: 16px; background: #fecaca; padding: 12px; border-radius: 8px;">
            Deductions
          </h3>
          <div>
            <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 12px; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px; margin-bottom: 8px;">
              <span>Component</span>
              <span>Amount (₹)</span>
            </div>
            ${deductions.map(component => `
              <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 14px; margin-bottom: 8px;">
                <span style="color: #111827;">${component.name}</span>
                <span style="color: #111827;">${component.monthly.toLocaleString('en-IN')}</span>
              </div>
            `).join('')}
            <div style="display: grid; grid-template-columns: 1fr auto; gap: 16px; font-size: 14px; font-weight: bold; border-top: 1px solid #e5e7eb; padding-top: 8px; background: #fecaca; padding: 8px; border-radius: 4px;">
              <span style="color: #991b1b;">Total Deductions (B)</span>
              <span style="color: #991b1b;">${totalDeductions.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Net Payable -->
      <div style="background: #dbeafe; padding: 24px; border-radius: 8px; margin-bottom: 32px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 20px; font-weight: bold; color: #1e3a8a;">Net Amount Payable (A-B):</span>
          <span style="font-size: 24px; font-weight: bold; color: #1e3a8a;">
            ${formatCurrency(netPayable)}
          </span>
        </div>
        <div style="margin-top: 8px; font-size: 14px; color: #1d4ed8;">
          <span style="font-weight: 600;">In Words: </span>
          <span style="font-style: italic;">${convertToWords(netPayable)} only</span>
        </div>
      </div>

      <!-- Footer -->
      <div style="border-top: 1px solid #e5e7eb; padding-top: 24px; text-align: center;">
        <p style="font-size: 12px; color: #6b7280; margin-bottom: 8px;">
          This is a computer-generated payslip and does not require a signature.
        </p>
        <p style="font-size: 10px; color: #9ca3af;">
          Confidential | Auto-generated by Diligentix Consulting | Generated on ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN')}
        </p>
      </div>
    </div>
  `;
}

// Utility function to convert number to words (simplified)
function convertToWords(amount: number): string {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  if (amount === 0) return 'Zero Rupees';

  const crores = Math.floor(amount / 10000000);
  const lakhs = Math.floor((amount % 10000000) / 100000);
  const thousands = Math.floor((amount % 100000) / 1000);
  const hundreds = Math.floor((amount % 1000) / 100);
  const remainder = amount % 100;

  let result = '';

  if (crores > 0) {
    result += convertHundreds(crores) + ' Crore ';
  }
  if (lakhs > 0) {
    result += convertHundreds(lakhs) + ' Lakh ';
  }
  if (thousands > 0) {
    result += convertHundreds(thousands) + ' Thousand ';
  }
  if (hundreds > 0) {
    result += ones[hundreds] + ' Hundred ';
  }
  if (remainder > 0) {
    if (remainder < 10) {
      result += ones[remainder];
    } else if (remainder < 20) {
      result += teens[remainder - 10];
    } else {
      result += tens[Math.floor(remainder / 10)] + ' ' + ones[remainder % 10];
    }
  }

  return result.trim() + ' Rupees';

  function convertHundreds(num: number): string {
    let result = '';
    const h = Math.floor(num / 100);
    const remainder = num % 100;

    if (h > 0) {
      result += ones[h] + ' Hundred ';
    }
    if (remainder > 0) {
      if (remainder < 10) {
        result += ones[remainder];
      } else if (remainder < 20) {
        result += teens[remainder - 10];
      } else {
        result += tens[Math.floor(remainder / 10)] + ' ' + ones[remainder % 10];
      }
    }

    return result.trim();
  }
}