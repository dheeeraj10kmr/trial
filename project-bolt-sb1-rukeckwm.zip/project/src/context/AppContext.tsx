import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { Employee, Payslip, EmailLog, Schedule } from '../types';
import { supabase } from '../lib/supabase';

interface AppState {
  employees: Employee[];
  payslips: Payslip[];
  emailLogs: EmailLog[];
  schedules: Schedule[];
  selectedEmployee: Employee | null;
  loading: boolean;
}

type AppAction = 
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_EMPLOYEES'; payload: Employee[] }
  | { type: 'ADD_EMPLOYEE'; payload: Employee }
  | { type: 'UPDATE_EMPLOYEE'; payload: Employee }
  | { type: 'DELETE_EMPLOYEE'; payload: string }
  | { type: 'SET_PAYSLIPS'; payload: Payslip[] }
  | { type: 'ADD_PAYSLIP'; payload: Payslip }
  | { type: 'UPDATE_PAYSLIP'; payload: Payslip }
  | { type: 'DELETE_PAYSLIP'; payload: string }
  | { type: 'ADD_EMAIL_LOG'; payload: EmailLog }
  | { type: 'ADD_SCHEDULE'; payload: Schedule }
  | { type: 'UPDATE_SCHEDULE'; payload: Schedule }
  | { type: 'DELETE_SCHEDULE'; payload: string }
  | { type: 'SELECT_EMPLOYEE'; payload: Employee | null };

const initialState: AppState = {
  employees: [],
  payslips: [],
  emailLogs: [],
  schedules: [],
  selectedEmployee: null,
  loading: false,
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  loadEmployees: () => Promise<void>;
  loadPayslips: () => Promise<void>;
  saveEmployee: (employee: Employee) => Promise<void>;
  deleteEmployee: (employeeId: string) => Promise<void>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_EMPLOYEES':
      return { ...state, employees: action.payload };
    case 'ADD_EMPLOYEE':
      return { ...state, employees: [...state.employees, action.payload] };
    case 'UPDATE_EMPLOYEE':
      return {
        ...state,
        employees: state.employees.map(emp => 
          emp.id === action.payload.id ? action.payload : emp
        ),
      };
    case 'DELETE_EMPLOYEE':
      return {
        ...state,
        employees: state.employees.filter(emp => emp.id !== action.payload),
      };
    case 'SET_PAYSLIPS':
      return { ...state, payslips: action.payload };
    case 'ADD_PAYSLIP':
      return { ...state, payslips: [...state.payslips, action.payload] };
    case 'UPDATE_PAYSLIP':
      return {
        ...state,
        payslips: state.payslips.map(payslip => 
          payslip.id === action.payload.id ? action.payload : payslip
        ),
      };
    case 'DELETE_PAYSLIP':
      return {
        ...state,
        payslips: state.payslips.filter(payslip => payslip.id !== action.payload),
      };
    case 'ADD_EMAIL_LOG':
      return { ...state, emailLogs: [...state.emailLogs, action.payload] };
    case 'ADD_SCHEDULE':
      return { ...state, schedules: [...state.schedules, action.payload] };
    case 'UPDATE_SCHEDULE':
      return {
        ...state,
        schedules: state.schedules.map(schedule => 
          schedule.id === action.payload.id ? action.payload : schedule
        ),
      };
    case 'DELETE_SCHEDULE':
      return {
        ...state,
        schedules: state.schedules.filter(schedule => schedule.id !== action.payload),
      };
    case 'SELECT_EMPLOYEE':
      return { ...state, selectedEmployee: action.payload };
    default:
      return state;
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load employees from Supabase
  const loadEmployees = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading employees:', error);
        return;
      }

      const employees: Employee[] = data.map(emp => ({
        id: emp.id,
        name: emp.name,
        empCode: emp.emp_code,
        designation: emp.designation,
        empType: emp.emp_type,
        location: emp.location,
        uan: emp.uan,
        pan: emp.pan,
        pfNumber: emp.pf_number,
        doj: emp.doj,
        email: emp.email,
        ctcStructure: emp.ctc_structure || [],
        salaryStructure: emp.salary_structure || [],
      }));

      dispatch({ type: 'SET_EMPLOYEES', payload: employees });
    } catch (error) {
      console.error('Error loading employees:', error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  // Load payslips from database
  const loadPayslips = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Get all salary records grouped by employee, month, year
      const { data, error } = await supabase
        .from('empsalary')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading payslips:', error);
        return;
      }

      // Group salary components by employee, month, year
      const payslipMap = new Map<string, any>();
      
      data.forEach(record => {
        const key = `${record.emp_code}_${record.month}_${record.year}`;
        
        if (!payslipMap.has(key)) {
          payslipMap.set(key, {
            id: key,
            employeeId: record.emp_code,
            month: record.month,
            year: record.year,
            salaryComponents: [],
            generatedDate: record.created_at,
            status: 'generated' as const,
          });
        }
        
        const payslip = payslipMap.get(key);
        payslip.salaryComponents.push({
          id: record.component_id,
          name: record.component_name,
          monthly: record.amount,
          ytd: record.amount, // Will be calculated properly when viewing
          type: record.type,
        });
      });

      // Calculate totals for each payslip
      const payslips: Payslip[] = Array.from(payslipMap.values()).map(payslip => {
        const earnings = payslip.salaryComponents.filter((comp: any) => comp.type === 'earning');
        const deductions = payslip.salaryComponents.filter((comp: any) => comp.type === 'deduction');
        
        const totalEarnings = earnings.reduce((sum: number, comp: any) => sum + comp.monthly, 0);
        const totalDeductions = deductions.reduce((sum: number, comp: any) => sum + comp.monthly, 0);
        const netPayable = totalEarnings - totalDeductions;

        return {
          ...payslip,
          payslipData: { paidDays: 22, leaveEncashmentDays: 0, noticePay: 0 },
          totalEarnings,
          totalDeductions,
          netPayable,
        };
      });

      dispatch({ type: 'SET_PAYSLIPS', payload: payslips });
    } catch (error) {
      console.error('Error loading payslips:', error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  // Save employee to Supabase
  const saveEmployee = async (employee: Employee) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });

      // Validate required fields
      if (!employee.name || !employee.empCode || !employee.email) {
        throw new Error('Name, Employee Code, and Email are required fields');
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(employee.email)) {
        throw new Error('Please enter a valid email address');
      }

      // Check if employee code already exists (for new employees)
      const existingEmployee = state.employees.find(emp => emp.id === employee.id);
      if (!existingEmployee) {
        const { data: existingEmpCode } = await supabase
          .from('employees')
          .select('id')
          .eq('emp_code', employee.empCode);

        if (existingEmpCode && existingEmpCode.length > 0) {
          throw new Error(`Employee code ${employee.empCode} already exists`);
        }
      }

      // Generate numeric ID if not provided (for compatibility with bigint)
      const employeeId = employee.id || Date.now().toString();

      const employeeData = {
        id: employeeId,
        name: employee.name.trim(),
        emp_code: employee.empCode.trim().toUpperCase(),
        designation: employee.designation?.trim() || '',
        emp_type: employee.empType || 'Full Time',
        location: employee.location?.trim() || '',
        uan: employee.uan?.trim() || '',
        pan: employee.pan?.trim().toUpperCase() || '',
        pf_number: employee.pfNumber?.trim() || '',
        doj: employee.doj || '',
        email: employee.email.trim().toLowerCase(),
        ctc_structure: employee.ctcStructure || [],
        salary_structure: employee.salaryStructure || [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('employees')
        .upsert([employeeData], { 
          onConflict: 'id',
          ignoreDuplicates: false 
        });

      if (error) {
        console.error('Supabase error:', error);
        if (error.code === '23505') {
          throw new Error('Employee code already exists. Please use a different code.');
        }
        throw new Error(`Database error: ${error.message}`);
      }

      // Update local state
      const updatedEmployee = { ...employee, id: employeeId };
      const existingEmployeeIndex = state.employees.findIndex(emp => emp.id === employeeId);
      if (existingEmployeeIndex >= 0) {
        dispatch({ type: 'UPDATE_EMPLOYEE', payload: updatedEmployee });
      } else {
        dispatch({ type: 'ADD_EMPLOYEE', payload: updatedEmployee });
      }

      console.log('Employee saved successfully');
    } catch (error) {
      console.error('Error saving employee:', error);
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  // Delete employee from Supabase
  const deleteEmployee = async (employeeId: string) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });

      // Get employee details first to get emp_code
      const employee = state.employees.find(emp => emp.id === employeeId);
      if (!employee) {
        throw new Error('Employee not found');
      }

      // Delete salary records using emp_code
      const { error: salaryError } = await supabase
        .from('empsalary')
        .delete()
        .eq('emp_code', employee.empCode);

      if (salaryError) {
        console.warn('Error deleting salary records:', salaryError);
        // Continue with employee deletion even if salary deletion fails
      }

      // Delete from Supabase
      const { error } = await supabase
        .from('employees')
        .delete()
        .eq('id', employeeId);

      if (error) {
        console.error('Error deleting employee:', error);
        throw error;
      }

      // Update local state
      dispatch({ type: 'DELETE_EMPLOYEE', payload: employeeId });

      console.log('Employee deleted successfully');
    } catch (error) {
      console.error('Error deleting employee:', error);
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  // Load data on mount
  useEffect(() => {
    loadEmployees();
    loadPayslips();
  }, []);

  return (
    <AppContext.Provider value={{ 
      state, 
      dispatch, 
      loadEmployees,
      loadPayslips,
      saveEmployee, 
      deleteEmployee 
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}