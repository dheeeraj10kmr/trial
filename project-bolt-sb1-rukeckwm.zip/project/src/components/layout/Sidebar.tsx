import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Mail, 
  Settings, 
  Building2,
  Calendar,
  History
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Employees', href: '/employees', icon: Users },
  { name: 'Generate Payslip', href: '/generate', icon: FileText },
  { name: 'Payslips Generated', href: '/payslips', icon: History },
  { name: 'Email Scheduler', href: '/scheduler', icon: Calendar },
  { name: 'Email Logs', href: '/emails', icon: Mail },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export default function Sidebar() {
  return (
    <div className="w-64 bg-white shadow-lg border-r border-gray-200 min-h-screen">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center">
          <img 
            src="/src/assets/LogoInv.png" 
            alt="Diligentix Logo" 
            className="h-8 w-8 object-contain"
            onError={(e) => {
              // Fallback to Building2 icon if image fails to load
              e.currentTarget.style.display = 'none';
              e.currentTarget.nextElementSibling.style.display = 'block';
            }}
          />
          <Building2 className="h-8 w-8 text-blue-600" style={{ display: 'none' }} />
          <div className="ml-3">
            <h1 className="text-xl font-bold text-gray-900">Diligentix</h1>
            <p className="text-sm text-gray-600">Payslip Generator</p>
          </div>
        </div>
      </div>
      
      <nav className="mt-6 px-3">
        {navigation.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            className={({ isActive }) =>
              `group flex items-center px-3 py-3 text-sm font-medium rounded-lg mb-1 transition-all duration-200 ${
                isActive
                  ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600'
                  : 'text-gray-700 hover:bg-gray-50 hover:text-blue-600'
              }`
            }
          >
            <item.icon className="h-5 w-5 mr-3 flex-shrink-0" />
            {item.name}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}