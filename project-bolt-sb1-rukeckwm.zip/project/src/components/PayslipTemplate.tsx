import React from 'react';
import { Employee, SalaryComponent, CTCComponent } from '../types';
import { format } from 'date-fns';

interface PayslipTemplateProps {
  employee: Employee & { paidDays: number; leaveEncashmentDays: number; noticePay: number };
  month: string;
  year: number;
  salaryComponents: SalaryComponent[];
  totalEarnings: number;
  totalDeductions: number;
  netPayable: number;
}

export default function PayslipTemplate({
  employee,
  month,
  year,
  salaryComponents,
  totalEarnings,
  totalDeductions,
  netPayable,
}: PayslipTemplateProps) {
  const earnings = salaryComponents.filter(comp => comp.type === 'earning');
  const deductions = salaryComponents.filter(comp => comp.type === 'deduction');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const totalCTC = employee.ctcStructure?.reduce((sum, comp) => sum + comp.perAnnum, 0) || 0;

  return (
    <div id="payslip-template" className="bg-white p-8 max-w-4xl mx-auto font-sans">
      {/* Header */}
      <div className="border-b-2 border-blue-600 pb-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center">
              <img 
                src="/src/assets/LogoInv.png" 
                alt="Diligentix Logo" 
                className="w-12 h-12 object-contain"
                onError={(e) => {
                  // Fallback to text logo if image fails
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling.style.display = 'block';
                }}
              />
              <span className="text-white font-bold text-xl" style={{ display: 'none' }}>DC</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Diligentix Consulting</h1>
              <p className="text-sm text-gray-600">Payslip for {month} {year}</p>
            </div>
          </div>
          <div className="text-right text-xs text-gray-500">
            <p>Office No. 6571/6572/17,</p>
            <p>Viman Nagar, Nashik-422207,</p>
            <p>Maharashtra, India.</p>
            <p>CIN: U62099MH2024OPC436737</p>
          </div>
        </div>
      </div>

      {/* Employee Information */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Employee Name:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.name}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Emp Code:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.empCode}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Designation:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.designation}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Emp Type:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.empType}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Location:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.location}</span>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">UAN:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.uan}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">PAN:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.pan}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">PF Number:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.pfNumber}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">DOJ:</span>
            <span className="col-span-2 text-sm text-gray-900">
              {new Date(employee.doj).toLocaleDateString('en-IN')}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <span className="text-sm font-medium text-gray-700">Paid Days:</span>
            <span className="col-span-2 text-sm text-gray-900">{employee.paidDays}</span>
          </div>
        </div>
      </div>

      {/* CTC Structure */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 bg-purple-50 p-3 rounded-lg">
          CTC Structure (Annual)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full border border-gray-200 rounded-lg">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Component</th>
                <th className="px-4 py-2 text-right text-sm font-medium text-gray-700 border-b">Per Month (₹)</th>
                <th className="px-4 py-2 text-right text-sm font-medium text-gray-700 border-b">Per Annum (₹)</th>
              </tr>
            </thead>
            <tbody>
              {employee.ctcStructure?.map((component, index) => (
                <tr key={component.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-4 py-2 text-sm text-gray-900 border-b">{component.name}</td>
                  <td className="px-4 py-2 text-sm text-gray-900 text-right border-b">
                    {component.perMonth.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-2 text-sm text-gray-900 text-right border-b">
                    {component.perAnnum.toLocaleString('en-IN')}
                  </td>
                </tr>
              ))}
              <tr className="bg-purple-100 font-semibold">
                <td className="px-4 py-2 text-sm text-purple-900">Total CTC</td>
                <td className="px-4 py-2 text-sm text-purple-900 text-right">
                  {Math.round(totalCTC / 12).toLocaleString('en-IN')}
                </td>
                <td className="px-4 py-2 text-sm text-purple-900 text-right">
                  {totalCTC.toLocaleString('en-IN')}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Salary Details */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        {/* Earnings */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 bg-green-50 p-3 rounded-lg">
            Earnings
          </h3>
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4 text-xs font-medium text-gray-700 border-b pb-2">
              <span>Component</span>
              <span className="text-right">Current Month (₹)</span>
              <span className="text-right">Year to Date (₹)</span>
            </div>
            {earnings.map((component) => (
              <div key={component.id} className="grid grid-cols-3 gap-4 text-sm">
                <span className="text-gray-900">{component.name}</span>
                <span className="text-right text-gray-900">
                  {component.monthly.toLocaleString('en-IN')}
                </span>
                <span className="text-right text-gray-900">
                  {component.ytd.toLocaleString('en-IN')}
                </span>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-4 text-sm font-bold border-t pt-2 bg-green-50 p-2 rounded">
              <span className="text-green-800">Total Earnings (A)</span>
              <span className="text-right text-green-800">
                {totalEarnings.toLocaleString('en-IN')}
              </span>
              <span className="text-right text-green-800">
                {earnings.reduce((sum, comp) => sum + comp.ytd, 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {/* Deductions */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 bg-red-50 p-3 rounded-lg">
            Deductions
          </h3>
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4 text-xs font-medium text-gray-700 border-b pb-2">
              <span>Component</span>
              <span className="text-right">Current Month (₹)</span>
              <span className="text-right">Year to Date (₹)</span>
            </div>
            {deductions.map((component) => (
              <div key={component.id} className="grid grid-cols-3 gap-4 text-sm">
                <span className="text-gray-900">{component.name}</span>
                <span className="text-right text-gray-900">
                  {component.monthly.toLocaleString('en-IN')}
                </span>
                <span className="text-right text-gray-900">
                  {component.ytd.toLocaleString('en-IN')}
                </span>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-4 text-sm font-bold border-t pt-2 bg-red-50 p-2 rounded">
              <span className="text-red-800">Total Deductions (B)</span>
              <span className="text-right text-red-800">
                {totalDeductions.toLocaleString('en-IN')}
              </span>
              <span className="text-right text-red-800">
                {deductions.reduce((sum, comp) => sum + comp.ytd, 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Net Payable */}
      <div className="bg-blue-50 p-6 rounded-lg mb-8">
        <div className="flex justify-between items-center">
          <span className="text-xl font-bold text-blue-900">Net Amount Payable (A-B):</span>
          <span className="text-2xl font-bold text-blue-900">
            {formatCurrency(netPayable)}
          </span>
        </div>
        <div className="mt-2 text-sm text-blue-700">
          <span className="font-medium">In Words: </span>
          <span className="italic">{convertToWords(netPayable)} only</span>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 pt-6 text-center">
        <p className="text-xs text-gray-500 mb-2">
          This is a computer-generated payslip and does not require a signature.
        </p>
        <p className="text-xs text-gray-400">
          Confidential | Auto-generated by Diligentix Consulting | Generated on {format(new Date(), 'dd/MM/yyyy HH:mm')}
        </p>
      </div>
    </div>
  );
}

// Utility function to convert number to words (simplified)
function convertToWords(amount: number): string {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  if (amount === 0) return 'Zero Rupees';

  const crores = Math.floor(amount / 10000000);
  const lakhs = Math.floor((amount % 10000000) / 100000);
  const thousands = Math.floor((amount % 100000) / 1000);
  const hundreds = Math.floor((amount % 1000) / 100);
  const remainder = amount % 100;

  let result = '';

  if (crores > 0) {
    result += convertHundreds(crores) + ' Crore ';
  }
  if (lakhs > 0) {
    result += convertHundreds(lakhs) + ' Lakh ';
  }
  if (thousands > 0) {
    result += convertHundreds(thousands) + ' Thousand ';
  }
  if (hundreds > 0) {
    result += ones[hundreds] + ' Hundred ';
  }
  if (remainder > 0) {
    if (remainder < 10) {
      result += ones[remainder];
    } else if (remainder < 20) {
      result += teens[remainder - 10];
    } else {
      result += tens[Math.floor(remainder / 10)] + ' ' + ones[remainder % 10];
    }
  }

  return result.trim() + ' Rupees';

  function convertHundreds(num: number): string {
    let result = '';
    const h = Math.floor(num / 100);
    const remainder = num % 100;

    if (h > 0) {
      result += ones[h] + ' Hundred ';
    }
    if (remainder > 0) {
      if (remainder < 10) {
        result += ones[remainder];
      } else if (remainder < 20) {
        result += teens[remainder - 10];
      } else {
        result += tens[Math.floor(remainder / 10)] + ' ' + ones[remainder % 10];
      }
    }

    return result.trim();
  }
}