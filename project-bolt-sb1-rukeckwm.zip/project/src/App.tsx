import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import PayslipGenerator from './pages/PayslipGenerator';
import PayslipsGenerated from './pages/PayslipsGenerated';
import EmailScheduler from './pages/EmailScheduler';
import EmailLogs from './pages/EmailLogs';
import Settings from './pages/Settings';

function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="employees" element={<Employees />} />
            <Route path="generate" element={<PayslipGenerator />} />
            <Route path="payslips" element={<PayslipsGenerated />} />
            <Route path="scheduler" element={<EmailScheduler />} />
            <Route path="emails" element={<EmailLogs />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </Router>
    </AppProvider>
  );
}

export default App;