# Diligentix Payslip Generator

A comprehensive payslip generation and management system built with React, TypeScript, and Supabase.

## Features

- **Employee Management**: Add, edit, and manage employee information with CTC and salary structures
- **Payslip Generation**: Generate professional payslips with automatic YTD calculations
- **Email Integration**: Send payslips via email with SMTP configuration
- **Payslip History**: View and manage previously generated payslips
- **Email Scheduling**: Schedule automatic payslip delivery
- **Email Logs**: Track email delivery status and history
- **Settings Management**: Configure company information, email templates, and SMTP settings

## Setup Instructions

### 1. Clone and Install

```bash
git clone <repository-url>
cd diligentix-payslip-generator
npm install
```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
# Supabase Configuration
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key

# SMTP Email Configuration
VITE_SMTP_HOST=smtp.gmail.com
VITE_SMTP_PORT=587
VITE_SMTP_SECURE=false
VITE_SMTP_USERNAME=your-email@yourdomain.com
VITE_SMTP_PASSWORD=your-app-password
VITE_SMTP_FROM_EMAIL=noreply@yourdomain.com
VITE_SMTP_FROM_NAME=Your Company Name
```

### 3. Email Configuration Options

#### Option 1: SMTP Configuration (Recommended)

**For Gmail:**
1. Enable 2-Factor Authentication on your Google account
2. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate a password for "Mail"
3. Use these settings:
   ```env
   VITE_SMTP_HOST=smtp.gmail.com
   VITE_SMTP_PORT=587
   VITE_SMTP_SECURE=false
   VITE_SMTP_USERNAME=your-gmail@gmail.com
   VITE_SMTP_PASSWORD=your-16-character-app-password
   ```

**For Custom Domain (cPanel/WHM):**
1. Create an email account in your hosting control panel
2. Get SMTP settings from your hosting provider
3. Use these settings:
   ```env
   VITE_SMTP_HOST=mail.yourdomain.com
   VITE_SMTP_PORT=587
   VITE_SMTP_SECURE=false
   VITE_SMTP_USERNAME=noreply@yourdomain.com
   VITE_SMTP_PASSWORD=your-email-password
   ```

**For Outlook/Hotmail:**
```env
VITE_SMTP_HOST=smtp-mail.outlook.com
VITE_SMTP_PORT=587
VITE_SMTP_SECURE=false
```

#### Option 2: Settings Page Configuration

If you prefer not to use environment variables, you can configure SMTP settings through the application:

1. Go to Settings → Email tab
2. Fill in your SMTP configuration
3. Test the connection
4. Save the configuration

### 4. Backend Email Service (Required for Production)

To actually send emails, you need to implement a backend service. Create an API endpoint at `/api/send-email` that:

1. Receives SMTP configuration and email data
2. Uses a server-side email library (like Nodemailer for Node.js)
3. Sends the email through your SMTP server

**Example Node.js/Express implementation:**

```javascript
// server.js
const express = require('express');
const nodemailer = require('nodemailer');
const app = express();

app.use(express.json());

app.post('/api/send-email', async (req, res) => {
  try {
    const { smtp, email } = req.body;
    
    const transporter = nodemailer.createTransporter({
      host: smtp.host,
      port: smtp.port,
      secure: smtp.secure,
      auth: {
        user: smtp.username,
        pass: smtp.password,
      },
    });

    await transporter.sendMail({
      from: email.from,
      to: email.to,
      subject: email.subject,
      html: email.html,
      text: email.text,
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Email error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(3001, () => {
  console.log('Email service running on port 3001');
});
```

### 5. Development

```bash
npm run dev
```

### 6. Production Deployment

```bash
npm run build
```

## Email Service Integration

The application supports multiple email service integrations:

1. **SMTP (Recommended)**: Direct SMTP server connection
2. **EmailJS**: Client-side email service (for development/testing)
3. **Webhook Services**: Zapier, Make.com, or custom webhooks

For production use, implement the backend email service as described above.

## Features Overview

### Employee Management
- Add/edit employee information
- CTC structure configuration
- Salary structure setup
- Employee data persistence in Supabase

### Payslip Generation
- Month/year validation (prevents future dates)
- Automatic paid days calculation
- DOJ-based restrictions
- YTD calculations
- PDF generation
- Email delivery

### Email System
- SMTP configuration
- Email templates with variables
- Test email functionality
- Bulk email sending
- Email delivery tracking

### Settings
- Company information
- SMTP configuration
- Email templates
- Security settings
- Appearance customization

## Support

For technical support or questions, please contact the development team.